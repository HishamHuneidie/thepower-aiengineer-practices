"""Paso 2 · El mismo trabajo, repartido en un EQUIPO con LangGraph: supervisor + investigador + redactor + revisor.

Patron supervisor: los trabajadores nunca hablan entre si. Cada uno lee y escribe en el ESTADO COMUN
(la memoria compartida) y devuelve el control al supervisor, que decide quien sigue (el handoff).
"""
import json
import time
from typing import TypedDict

from langchain_ollama import ChatOllama
from langgraph.graph import END, START, StateGraph

from comun import (FORMATO, MODELO, SECCIONES, TAREA, buscar_web, evaluar_informe, formatear_fuentes, guardar,
                   imprimir_metricas)

llm = ChatOllama(model=MODELO, temperature=0, num_predict=700)
juez = ChatOllama(model=MODELO, temperature=0, format="json", num_predict=150)   # decisiones cortas en JSON
MAX_TURNOS = 8          # tope de decisiones del supervisor: sin tope, un equipo puede pasarse la pelota sin fin
MAX_REESCRITURAS = 1    # el revisor puede devolver el borrador una vez, no infinitas
MAX_RONDAS_INV = 2      # como mucho 2 rondas de busqueda


class Estado(TypedDict, total=False):
    tarea: str
    fuentes: list        # lo que deja el investigador
    borrador: str        # lo que deja el redactor
    revision: dict       # lo que deja el revisor: {"aprobado": bool, "cambios": str}
    reescrituras: int
    rondas_inv: int
    siguiente: str       # la decision del supervisor
    turnos: int
    rastro: list         # quien hizo que, en orden (para verlo en clase)
    llamadas_llm: int


# ---------------------------------------------------------------- el supervisor: decide, no trabaja
SUPERVISOR = """Eres el supervisor de un equipo con tres trabajadores:
- investigador: busca informacion en la web sobre la tarea.
- redactor: escribe el resumen usando las fuentes del investigador.
- revisor: comprueba que el resumen cumple el formato y usa las fuentes.
Mira el ESTADO y decide quien trabaja ahora, o FIN si el resumen esta revisado y aprobado.
Responde SOLO con JSON: {{"siguiente": "investigador|redactor|revisor|FIN", "motivo": "<una frase>"}}

TAREA: {tarea}
ESTADO:
- fuentes: {fuentes}
- borrador: {borrador}
- revision: {revision}"""


def resumen_estado(e: Estado) -> dict:
    rev = e.get("revision")
    return {"fuentes": f"{len(e['fuentes'])} fuentes" if e.get("fuentes") else "ninguna todavia",
            "borrador": (f"escrito ({evaluar_informe(e['borrador'])['secciones']} secciones)"
                         if e.get("borrador") else "no hay"),
            "revision": ("pendiente" if not rev else "APROBADO" if rev["aprobado"] else f"pide cambios: {rev['cambios']}")}


def regla(e: Estado) -> str:
    """Lo que haria un jefe sensato. Lo usamos para CORREGIR al supervisor si elige algo imposible."""
    if not e.get("fuentes"):
        return "investigador"
    if not e.get("borrador"):
        return "redactor"
    if not e.get("revision"):
        return "revisor"
    if not e["revision"]["aprobado"] and e.get("reescrituras", 0) < MAX_REESCRITURAS:
        return "redactor"
    return "FIN"


def supervisor(e: Estado) -> Estado:
    turnos = e.get("turnos", 0) + 1
    if turnos > MAX_TURNOS:
        return {"siguiente": "FIN", "turnos": turnos, "rastro": e["rastro"] + ["SUPERVISOR · tope de turnos -> FIN"]}
    r = json.loads(juez.invoke(SUPERVISOR.format(tarea=e["tarea"], **resumen_estado(e))).content)
    eleccion, motivo = r.get("siguiente", ""), r.get("motivo", "")
    linea = f"SUPERVISOR · -> {eleccion} ({motivo})"
    sensata = regla(e)
    # Barandillas en codigo: no se redacta sin fuentes, no se acaba sin revisar, no se reescribe sin fin.
    # Unica libertad: pedir UNA ronda mas de investigacion antes del borrador. En la primera version le dejabamos
    # investigar sin limite y el supervisor mando 8 veces al investigador (17 fuentes, 0 informe)
    extra_ok = eleccion == "investigador" and not e.get("borrador") and e.get("rondas_inv", 0) < MAX_RONDAS_INV
    if eleccion != sensata and not extra_ok:
        linea += f"  !! corregido por el codigo -> {sensata}"
        eleccion = sensata
    return {"siguiente": eleccion, "turnos": turnos, "llamadas_llm": e["llamadas_llm"] + 1,
            "rastro": e["rastro"] + [linea]}


# ---------------------------------------------------------------- los trabajadores: cada uno, UNA especialidad
PLANIFICAR = """Eres un investigador. Para la TAREA, escribe 3 consultas de buscador distintas y concretas
(pueden ser en ingles si el tema es tecnico). Responde SOLO con JSON: {{"consultas": ["...", "...", "..."]}}
TAREA: {tarea}"""


def investigador(e: Estado) -> Estado:
    consultas = json.loads(juez.invoke(PLANIFICAR.format(tarea=e["tarea"])).content).get("consultas", [])[:3]
    fuentes, vistas = list(e.get("fuentes", [])), {f["url"] for f in e.get("fuentes", [])}
    for c in consultas or [e["tarea"]]:
        for f in buscar_web(c, n=3):
            if f["url"] not in vistas:
                vistas.add(f["url"])
                fuentes.append(f)
    return {"fuentes": fuentes, "rondas_inv": e.get("rondas_inv", 0) + 1, "llamadas_llm": e["llamadas_llm"] + 1,
            "rastro": e["rastro"] + [f"INVESTIGADOR · {len(consultas)} consultas -> {len(fuentes)} fuentes"]
                     + [f"   - {c}" for c in consultas]}


REDACTAR = """Eres un redactor tecnico. Escribe en espanol un resumen para un equipo tecnico que responda la TAREA
usando SOLO las FUENTES (no uses conocimientos propios). {formato}
{cambios}
TAREA: {tarea}
FUENTES:
{fuentes}"""


def redactor(e: Estado) -> Estado:
    rev = e.get("revision")
    cambios = f"El revisor pidio estos cambios, aplicalos: {rev['cambios']}" if rev and not rev["aprobado"] else ""
    texto = llm.invoke(REDACTAR.format(formato=FORMATO, cambios=cambios, tarea=e["tarea"],
                                       fuentes=formatear_fuentes(e["fuentes"][:10], 400))).content.strip()  # 10 fuentes bastan y caben en el contexto
    rees = e.get("reescrituras", 0) + (1 if cambios else 0)
    return {"borrador": texto, "revision": None, "reescrituras": rees, "llamadas_llm": e["llamadas_llm"] + 1,
            "rastro": e["rastro"] + [f"REDACTOR · {'reescribe' if cambios else 'escribe'} borrador "
                                     f"({evaluar_informe(texto)['secciones']} secciones, {len(texto.split())} palabras)"]}


REVISAR = """Eres un revisor exigente. Comprueba el BORRADOR: (1) tiene los titulos {secciones};
(2) cada dato lleva una cita [n] a las fuentes; (3) responde a la TAREA.
Responde SOLO con JSON: {{"aprobado": true/false, "cambios": "<que hay que cambiar, o vacio>"}}
TAREA: {tarea}
BORRADOR:
{borrador}"""


def revisor(e: Estado) -> Estado:
    r = json.loads(juez.invoke(REVISAR.format(secciones=", ".join(SECCIONES), tarea=e["tarea"],
                                              borrador=e["borrador"])).content)
    faltan = evaluar_informe(e["borrador"])["faltan"]
    aprobado = bool(r.get("aprobado")) and not faltan     # el formato lo comprueba tambien el CODIGO
    cambios = (f"faltan las secciones {faltan}. " if faltan else "") + (r.get("cambios") or "")
    return {"revision": {"aprobado": aprobado, "cambios": cambios}, "llamadas_llm": e["llamadas_llm"] + 1,
            "rastro": e["rastro"] + [f"REVISOR · {'APROBADO' if aprobado else 'pide cambios: ' + cambios}"]}


# ---------------------------------------------------------------- el grafo: estrella alrededor del supervisor
def construir():
    g = StateGraph(Estado)
    g.add_node("supervisor", supervisor)
    for nombre, fn in (("investigador", investigador), ("redactor", redactor), ("revisor", revisor)):
        g.add_node(nombre, fn)
        g.add_edge(nombre, "supervisor")         # handoff de vuelta: todos devuelven el control al jefe
    g.add_edge(START, "supervisor")
    g.add_conditional_edges("supervisor", lambda e: e["siguiente"],
                            {"investigador": "investigador", "redactor": "redactor", "revisor": "revisor", "FIN": END})
    return g.compile()


if __name__ == "__main__":
    print(f"TAREA: {TAREA}\n")
    t0, visto = time.time(), 0
    final = {}
    for estado in construir().stream({"tarea": TAREA, "rastro": [], "llamadas_llm": 0}, {"recursion_limit": 30},
                                     stream_mode="values"):
        for linea in estado.get("rastro", [])[visto:]:
            print(linea)
        visto, final = len(estado.get("rastro", [])), estado
    informe = final.get("borrador", "")
    print("\n=== INFORME\n" + informe)
    m = {"llamadas_llm": final["llamadas_llm"], "segundos": round(time.time() - t0), "turnos": final.get("turnos"),
         **evaluar_informe(informe)}
    imprimir_metricas(m)
    guardar("02_equipo_langgraph", informe, m)
