"""Piezas comunes a las dos implementaciones: la tarea, la herramienta de busqueda y como medimos el resultado.

La idea de la sesion es comparar LangGraph y CrewAI en IGUALDAD de condiciones: misma tarea, mismo modelo
(llama3.1 en local con Ollama), misma herramienta de busqueda y la misma forma de puntuar el informe final.
"""
import json
import re
import time
from pathlib import Path

SALIDAS = Path(__file__).parent / "salidas"
SALIDAS.mkdir(exist_ok=True)

MODELO = "llama3.1"
OLLAMA_URL = "http://localhost:11434"

# La tarea "de varias fases": hay que buscar, ordenar lo encontrado y escribirlo con un formato fijo
TAREA = ("Investiga que es el protocolo A2A (Agent2Agent) y escribe un resumen estructurado para un equipo "
         "tecnico: que es, quien lo impulsa, como funciona y en que se diferencia de MCP.")

# El formato que pedimos. Lo comprobamos con codigo, no a ojo
SECCIONES = ["Que es", "Quien lo impulsa", "Como funciona", "A2A vs MCP"]
FORMATO = ("Usa exactamente estos titulos, cada uno en su propia linea empezando por '## ': "
           + ", ".join(f"'## {s}'" for s in SECCIONES)
           + ". Debajo de cada titulo, 2-3 frases. Cada dato lleva su fuente entre corchetes, por ejemplo [2].")


# ---------------------------------------------------------------- la herramienta: DuckDuckGo (gratis, sin API key)
# Es la misma busqueda que el deep research de la Sesion 7 (multimodal-agent/research.py)
def buscar_web(consulta: str, n: int = 4) -> list:
    from ddgs import DDGS
    from ddgs.exceptions import DDGSException
    try:
        resultados = DDGS().text(consulta, max_results=n)
    except DDGSException:           # "No results" o demasiadas busquedas seguidas: seguimos con lo que haya
        resultados = []
    time.sleep(1)                   # DuckDuckGo corta si le lanzas muchas busquedas seguidas
    return [{"titulo": r["title"], "url": r["href"], "texto": r["body"]} for r in resultados]


def formatear_fuentes(fuentes: list, max_chars: int = 300) -> str:
    return "\n".join(f"[{i}] {f['titulo']}. {f['texto'][:max_chars]}" for i, f in enumerate(fuentes, 1))


# ---------------------------------------------------------------- medir el informe (igual para los dos equipos)
def evaluar_informe(texto: str) -> dict:
    """Puntuacion objetiva: cuantas secciones del formato estan y cuantas citas [n] distintas hay."""
    presentes = [s for s in SECCIONES if re.search(rf"^#+\s*{re.escape(s)}", texto, re.M | re.I)]
    citas = sorted({int(n) for n in re.findall(r"\[(\d+)\]", texto)})
    return {"secciones": f"{len(presentes)}/{len(SECCIONES)}", "faltan": [s for s in SECCIONES if s not in presentes],
            "citas_distintas": len(citas), "palabras": len(texto.split())}


def guardar(nombre: str, informe: str, metricas: dict) -> None:
    (SALIDAS / f"{nombre}.md").write_text(informe, encoding="utf-8")
    (SALIDAS / f"{nombre}.json").write_text(json.dumps(metricas, ensure_ascii=False, indent=2), encoding="utf-8")


def imprimir_metricas(m: dict) -> None:
    print("\n=== METRICAS")
    for k in ("llamadas_llm", "segundos", "secciones", "faltan", "citas_distintas", "palabras"):
        if k in m:
            print(f"  {k:16} {m[k]}")
