# Sesión 9 · Equipos multi-agente: LangGraph vs CrewAI · Prompts para Claude Code

Estos son los prompts que usamos en la práctica, en el mismo orden que en clase. Cópialos y pégalos en Claude Code uno a uno.

**Cómo usarlos**
1. Pega el prompt del paso y deja que Claude Code proponga los cambios.
2. **Lee el código antes de aceptar** (y los comandos, como `pip install`, antes de permitirlos).
3. Ejecuta y compara con el apartado *Qué deberías ver*.
4. Si no sale lo esperado, vuelve a pedírselo con lo que has aprendido.

> Antes de empezar: Ollama con `llama3.1` (Sesión 1) y un entorno nuevo con `requirements.txt` (langgraph, langchain-ollama, ddgs y crewai: todo gratis y open source). Hoy no hay `.env`: la búsqueda es DuckDuckGo, sin claves. Sin GPU todo va en CPU: el equipo de LangGraph tarda unos 5 minutos y el de CrewAI puede pasar de 13; no lances dos a la vez.

El resultado de referencia, con todo el código comentado, está en la carpeta `multiagent-team` del material de la sesión.

---

## Paso 1 · Punto de partida: un agente unico

**Qué construye**

- El grafo de la Sesion 2: chatbot + ToolNode
- Herramienta: buscar(consulta) en DuckDuckGo
- Un unico prompt para todo el trabajo
- La tarea de A2A, con el formato

**Prompt**

```text
Parte del agente conversacional con herramientas de la Sesion 2 (chatbot + ToolNode + tools_condition) y cambia su herramienta por una busqueda web gratuita con DuckDuckGo (ddgs). Crea comun.py con la tarea (investigar el protocolo A2A y escribir un resumen para un equipo tecnico: que es, quien lo impulsa, como funciona y en que se diferencia de MCP), el formato con cuatro titulos exactos y citas [n], y una funcion evaluar_informe() que cuente con codigo las secciones presentes y las citas. En 01_agente_unico.py ejecuta el agente con esa tarea, muestra cada llamada a la herramienta y las metricas, y guardalas en salidas/.
```

**Qué deberías ver**

UNA sola busqueda y a escribir. 2 llamadas al modelo, 284 s. Formato perfecto: 4/4 secciones y 4 citas.

---

## Paso 2 · Equipo de 3 agentes + supervisor con LangGraph

**Qué construye**

- Supervisor: decide quien trabaja (JSON)
- Investigador: 3 consultas y busca
- Redactor: escribe SOLO con las fuentes
- Revisor: aprueba o pide cambios

**Prompt**

```text
Con LangGraph, convierte el agente unico en un equipo con patron supervisor: un nodo supervisor que decide en JSON quien trabaja ahora (investigador, redactor, revisor o FIN) y tres trabajadores. El investigador genera 3 consultas y busca con buscar_web; el redactor escribe el resumen solo con esas fuentes y el formato de comun.py; el revisor aprueba o pide cambios en JSON. Todos comparten un estado comun (TypedDict) y devuelven el control al supervisor. Anade un tope de turnos, un maximo de una reescritura y un rastro que muestre cada decision. Ejecutalo con la misma tarea.
```

**Qué deberías ver**

Dos rondas de busqueda, borrador, revision APROBADA y fin. Dos veces el codigo corrige al supervisor (!!).

---

## Paso 3 · El mismo equipo con CrewAI

**Qué construye**

- pip install crewai (sin pagar nada)
- 3 agentes: rol + objetivo + historia
- 3 tareas encadenadas con context=[...]
- El mismo llama3.1 local via LiteLLM

**Prompt**

```text
Instala crewai y monta el MISMO equipo con CrewAI: un agente investigador con la herramienta buscar_web, un redactor y un revisor, cada uno con su role, goal y backstory, y el mismo llama3.1 de Ollama (LLM(model='ollama_chat/llama3.1')). Define tres tareas encadenadas con context, usa el formato de comun.py y ejecutalo con Process.sequential y la misma tarea. Desactiva la telemetria, mide el tiempo de cada tarea y guarda las metricas igual que en LangGraph.
```

**Qué deberías ver**

2 busquedas, 12 llamadas y 815 s: el triple que LangGraph. Formato 4/4 pero solo 3 citas.

---

## Paso 4 · Comparar LangGraph y CrewAI

**Qué construye**

- Lee las metricas guardadas en salidas/
- Cuenta las lineas de codigo reales
- No llama al modelo: es instantaneo
- Tabla medida + tabla de valoracion

**Prompt**

```text
Crea 04_comparar.py: sin llamar al LLM, lee las metricas que guardaron los pasos 1 a 3 en salidas/ y cuenta las lineas de codigo de cada implementacion (sin comentarios ni prompts). Muestra una tabla lado a lado con lineas de codigo, llamadas al LLM, segundos, secciones del formato y citas, y otra tabla que valore control, rapidez de desarrollo, depuracion y en que casos elegirias LangGraph o CrewAI.
```

**Qué deberías ver**

LangGraph: mas codigo (110 lineas) y el mejor informe. CrewAI: 61 lineas y el triple de tiempo.

---

## Paso 5 · Cierre y material

**Qué construye**

- Patrones: supervisor, jerarquico, secuencial
- Handoff y memoria compartida en el codigo
- README con la comparativa
- Los dos ejercicios

**Prompt**

```text
Anade comentarios didacticos a los dos proyectos y un README que explique los patrones de coordinacion (supervisor, jerarquico, secuencial), el handoff, la memoria compartida y las diferencias entre LangGraph y CrewAI, con la tabla de 04_comparar.py. Deja el repositorio limpio para compartir como material de clase.
```

**Qué deberías ver**

El mismo supervisor de la slide 5 de teoria, ahora con codigo que funciona y barandillas.

---

## Ejercicio 1 · Un equipo de 2 agentes

**Qué construye**

- Define los 2 roles
- Conectalos con un estado comun
- Lanza una tarea real
- Observa el handoff

**Prompt**

```text
Con LangGraph, monta un equipo de dos agentes en secuencia para una tarea sencilla: un investigador que busca en la web con DuckDuckGo (ddgs) informacion sobre la semana laboral de 4 dias en Espana y un redactor que escribe con esas fuentes un resumen de 5 lineas con citas [n]. Comparten un estado comun (TypedDict) y el orden lo fijan las aristas. Muestra el resumen, las fuentes y dos frases sobre por que elegiste ese framework.
```

**Qué deberías ver**

Un resumen corto con citas [n] a las fuentes que encontro el investigador.

---

## Ejercicio 2 · El soporte de pedidos en equipo, en LangGraph y en CrewAI (reto)

**Qué construye**

- Parte del agente de la S2
- Un equipo de 2-3 agentes
- En LangGraph y en CrewAI
- Tabla comparativa

**Prompt**

```text
Parte del agente de pedidos de la Sesion 2 (herramienta consulta_pedido) y conviertelo en un equipo: un agente de pedidos con consulta_pedido, un agente de devoluciones con una herramienta politica_devolucion(motivo) y alguien que junte las respuestas en un solo mensaje al cliente. Hazlo dos veces: en LangGraph con un supervisor que decide en JSON quien trabaja (con tope de turnos y sin repetir trabajador) y en CrewAI con tres agentes y tareas encadenadas con context. Pruebalo con el mensaje 'El pedido 1234 me ha llegado roto, ¿como lo devuelvo? Y el 5678, ¿cuando llega?' y escribe una tabla que compare control, rapidez de desarrollo y coste.
```

**Qué deberías ver**

Una sola respuesta al cliente que cubre la devolucion del 1234 y la llegada del 5678.

---

*Material del Master AI Engineer · The Power · Ignacio de Pastors*
