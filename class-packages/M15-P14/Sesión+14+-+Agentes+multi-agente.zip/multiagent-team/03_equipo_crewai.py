"""Paso 3 · El MISMO equipo con CrewAI: defines roles y tareas, y el framework coordina.

    python 03_equipo_crewai.py               -> proceso secuencial (investigador -> redactor -> revisor)
    python 03_equipo_crewai.py --jerarquico  -> proceso jerarquico: CrewAI crea un "manager" (el supervisor)

Fijate en lo que NO escribimos: ni estado, ni nodos, ni aristas, ni el bucle. Eso lo pone CrewAI.
"""
import os
import sys
import time

# Antes de importar crewai: sin telemetria ni trazas en la nube (todo local, como el resto del master)
os.environ.update({"CREWAI_TELEMETRY_OPT_OUT": "true", "OTEL_SDK_DISABLED": "true", "CREWAI_TRACING_ENABLED": "false"})

from crewai import LLM, Agent, Crew, Process, Task   # noqa: E402
from crewai.tools import tool                        # noqa: E402

from comun import FORMATO, MODELO, OLLAMA_URL, TAREA, buscar_web, evaluar_informe, guardar, imprimir_metricas  # noqa: E402

# El mismo modelo local que en LangGraph. CrewAI habla con Ollama a traves de LiteLLM ("ollama_chat/...")
llm = LLM(model=f"ollama_chat/{MODELO}", base_url=OLLAMA_URL, temperature=0, max_tokens=700)


@tool("buscar_web")
def buscar(consulta: str) -> str:
    """Busca en la web y devuelve los 3 primeros resultados (titulo, url y extracto)."""
    fuentes = buscar_web(consulta, n=3)
    return "\n".join(f"- {f['titulo']} ({f['url']}): {f['texto'][:300]}" for f in fuentes) or "Sin resultados."


# ---------------------------------------------------------------- 1 · los agentes: rol + objetivo + historia
investigador = Agent(
    role="Investigador",
    goal="Encontrar en la web datos concretos y fiables sobre la tarea",
    backstory="Analista tecnico que siempre anota de donde saca cada dato.",
    tools=[buscar], llm=llm, max_iter=4, allow_delegation=False, verbose=True)
redactor = Agent(
    role="Redactor tecnico",
    goal="Escribir resumenes claros en espanol usando solo las notas del investigador",
    backstory="Escribe documentacion interna para equipos de ingenieria.",
    llm=llm, allow_delegation=False, verbose=True)
revisor = Agent(
    role="Revisor",
    goal="Comprobar que el resumen cumple el formato y que cada dato lleva su fuente",
    backstory="Editor exigente: si falta un titulo o una cita, lo corrige.",
    llm=llm, allow_delegation=False, verbose=True)

# ---------------------------------------------------------------- 2 · las tareas: que hay que entregar
investigar = Task(
    description="Busca informacion para esta tarea: {tarea} Haz entre 2 y 3 busquedas distintas.",
    expected_output="Como mucho 6 fuentes numeradas [1], [2]..., cada una en UNA linea: titulo, url y su dato clave.",
    agent=investigador)
redactar = Task(
    description="Con las notas del investigador, escribe el resumen de la tarea: {tarea} NO copies las notas: "
                "redacta el resumen. " + FORMATO,
    expected_output="El resumen en markdown con los 4 titulos y citas [n].",
    agent=redactor, context=[investigar])
revisar = Task(
    description="Revisa el resumen: que tenga los 4 titulos y que cada dato lleve cita [n]. "
                "Corrige lo que falle. " + FORMATO,
    expected_output="La version final del resumen, en markdown, y nada mas.",
    agent=revisor, context=[investigar, redactar])

if __name__ == "__main__":
    jerarquico = "--jerarquico" in sys.argv
    if jerarquico:
        # Supervisor automatico: un agente "manager" reparte las tareas usando la herramienta de delegar
        for t in (investigar, redactar, revisar):
            t.agent = None
        crew = Crew(agents=[investigador, redactor, revisor], tasks=[investigar, redactar, revisar],
                    process=Process.hierarchical, manager_llm=llm, verbose=True)
    else:
        crew = Crew(agents=[investigador, redactor, revisor], tasks=[investigar, redactar, revisar],
                    process=Process.sequential, verbose=True)

    t0 = time.time()
    # Al acabar cada tarea, cuanto llevamos: asi vemos donde se va el tiempo
    crew.task_callback = lambda salida: print(f"\n>>> TAREA TERMINADA · {salida.agent} · {round(time.time() - t0)} s\n")
    resultado = crew.kickoff(inputs={"tarea": TAREA})
    informe = resultado.raw
    print("\n=== INFORME\n" + informe)
    uso = resultado.token_usage
    m = {"proceso": "jerarquico" if jerarquico else "secuencial", "llamadas_llm": uso.successful_requests,
         "tokens": uso.total_tokens, "segundos": round(time.time() - t0), **evaluar_informe(informe)}
    imprimir_metricas(m)
    guardar("03_equipo_crewai" + ("_jerarquico" if jerarquico else ""), informe, m)
