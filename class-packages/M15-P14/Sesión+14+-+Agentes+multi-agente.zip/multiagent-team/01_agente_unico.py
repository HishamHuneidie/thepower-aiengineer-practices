"""Paso 1 · Punto de partida: UN agente con herramientas (el de la Sesion 2) ante una tarea de varias fases.

Es el mismo patron del agente de pedidos: nodo chatbot + ToolNode + arista condicional (el ciclo del agente).
Solo cambiamos la herramienta: en vez de consulta_pedido, buscar en la web.
"""
import time
from typing import Annotated, TypedDict

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama
from langgraph.graph import START, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode, tools_condition

from comun import FORMATO, MODELO, TAREA, buscar_web, evaluar_informe, formatear_fuentes, guardar, imprimir_metricas


@tool
def buscar(consulta: str) -> str:
    """Busca en la web y devuelve los 4 primeros resultados numerados (titulo y extracto)."""
    return formatear_fuentes(buscar_web(consulta)) or "Sin resultados."


tools = [buscar]


class State(TypedDict):
    messages: Annotated[list, add_messages]


modelo = ChatOllama(model=MODELO, temperature=0, num_predict=700).bind_tools(tools)
# UN solo prompt para TODO: investigar, decidir cuando parar, ordenar y redactar con formato
SYSTEM = SystemMessage("Eres un asistente de investigacion. Responde en espanol. Usa la herramienta buscar "
                       "tantas veces como necesites y despues escribe el resumen final. " + FORMATO)
llamadas = 0


def chatbot(state: State) -> dict:
    global llamadas
    llamadas += 1
    return {"messages": [modelo.invoke([SYSTEM] + state["messages"])]}


builder = StateGraph(State)
builder.add_node("chatbot", chatbot)
builder.add_node("tools", ToolNode(tools))
builder.add_edge(START, "chatbot")
builder.add_conditional_edges("chatbot", tools_condition)
builder.add_edge("tools", "chatbot")
grafo = builder.compile()

if __name__ == "__main__":
    print(f"TAREA: {TAREA}\n")
    t0, final = time.time(), ""
    # recursion_limit: tope de pasos del grafo, para que un bucle de busquedas no sea infinito
    for paso in grafo.stream({"messages": [HumanMessage(TAREA)]}, {"recursion_limit": 12}, stream_mode="updates"):
        for nodo, cambio in paso.items():
            msg = cambio["messages"][-1]
            if getattr(msg, "tool_calls", None):
                for c in msg.tool_calls:
                    print(f"  [{nodo}] pide tool -> {c['name']}({c['args']})")
            elif nodo == "tools":
                print(f"  [{nodo}] devuelve {msg.content.count(chr(10)) + 1} resultados")
            else:
                final = msg.content
                print(f"  [{nodo}] responde ({len(final.split())} palabras)")
    print("\n=== INFORME\n" + final)
    m = {"llamadas_llm": llamadas, "segundos": round(time.time() - t0), **evaluar_informe(final)}
    imprimir_metricas(m)
    guardar("01_agente_unico", final, m)
