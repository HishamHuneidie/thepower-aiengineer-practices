"""Paso 4 · LangGraph vs CrewAI sobre el mismo problema: tabla con lo MEDIDO en las ejecuciones reales.

No llama al LLM: lee las metricas que guardaron los pasos 1-3 (salidas/*.json) y cuenta lineas de codigo.
"""
import json
import re
from pathlib import Path

HERE = Path(__file__).parent
SAL = HERE / "salidas"


def lineas_de_codigo(fichero: str) -> int:
    """Lineas que hacen algo: sin blancos, sin comentarios y sin docstrings/prompts de varias lineas."""
    texto = re.sub(r'"""[\s\S]*?"""', "", (HERE / fichero).read_text(encoding="utf-8"))
    return sum(1 for l in texto.splitlines() if l.strip() and not l.strip().startswith("#"))


def cargar(nombre: str) -> dict:
    p = SAL / f"{nombre}.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}


col = {"Agente unico": ("01_agente_unico.py", cargar("01_agente_unico")),
       "LangGraph": ("02_equipo_langgraph.py", cargar("02_equipo_langgraph")),
       "CrewAI": ("03_equipo_crewai.py", cargar("03_equipo_crewai"))}
if (SAL / "03_equipo_crewai_jerarquico.json").exists():
    col["CrewAI jerarq."] = ("03_equipo_crewai.py", cargar("03_equipo_crewai_jerarquico"))

filas = [("Lineas de codigo", lambda f, m: lineas_de_codigo(f)),
         ("Llamadas al LLM", lambda f, m: m.get("llamadas_llm", "-")),
         ("Segundos (CPU)", lambda f, m: m.get("segundos", "-")),
         ("Secciones del formato", lambda f, m: m.get("secciones", "-")),
         ("Citas [n] distintas", lambda f, m: m.get("citas_distintas", "-")),
         ("Palabras", lambda f, m: m.get("palabras", "-"))]

ancho = 15
print("=== MEDIDO (mismo modelo llama3.1, misma tarea, misma busqueda)")
print(f"{'':24}" + "".join(f"{k:>{ancho}}" for k in col))
for nombre, fn in filas:
    print(f"{nombre:24}" + "".join(f"{str(fn(f, m)):>{ancho}}" for f, m in col.values()))

print("""
=== VALORACION (lo que hemos visto al construirlos)
                         LangGraph                          CrewAI
Como lo defines          nodos, aristas y estado            roles, objetivos y tareas
Quien decide el orden    tu (aristas) o tu supervisor       el framework (secuencial o manager)
Control del flujo        total: barandillas en codigo       limitado: max_iter, context, proceso
Ver que ha pasado        el rastro que tu escribes          el log verbose del framework
Rapidez de montaje       mas lento                          muy rapido
Cuando lo elegiria       produccion, flujos con reglas      prototipos, equipos por roles
""")
