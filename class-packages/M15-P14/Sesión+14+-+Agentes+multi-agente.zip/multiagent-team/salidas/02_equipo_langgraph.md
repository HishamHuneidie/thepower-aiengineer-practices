## Que es
El protocolo A2A (Agent2Agent) es un protocolo de comunicación abierto para agentes de inteligencia artificial (IA) diseñado para sistemas multiagente, que permite la interoperabilidad entre agentes de IA de diversos proveedores o aquellos creados utilizando diferentes marcos de agentes de IA [1]. El protocolo A2A permite a los agentes de IA comunicarse, colaborar y delegarse tareas entre sí sin intervención humana [5].

## Quien lo impulsa
El protocolo A2A fue presentado inicialmente por Google en abril de 2025 [3] y está impulsado por Google [5]. Actualmente, el protocolo A2A está contribuido a la Fundación Linux [6].

## Como funciona
El protocolo A2A funciona mediante la publicación de un documento en JSON llamado Agent Card, que declara las habilidades del agente, la ruta de comunicación y el mecanismo de autenticación [2]. Los agentes pueden entonces comunicarse y delegarse tareas entre sí de manera segura e interoperable [4].

## A2A vs MCP
El protocolo A2A se diferencia del protocolo MCP (Multi-Cloud Platform) en que A2A se enfoca en la comunicación y colaboración entre agentes de IA, mientras que MCP se enfoca en la conexión de agentes con herramientas y datos [9]. En un sistema real, se pueden apilar ambos protocolos, ya que cada agente puede poseer sus herramientas vía MCP y cooperar vía A2A [9].