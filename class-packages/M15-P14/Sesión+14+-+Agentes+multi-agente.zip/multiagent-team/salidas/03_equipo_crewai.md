## Que es
El protocolo A2A (Agent2Agent) es un estándar abierto que permite a los agentes de IA delegar tareas entre frameworks [1]. Esto significa que los agentes pueden comunicarse y colaborar entre sí de manera segura y eficiente [1]. El protocolo A2A es una forma de que los agentes de IA puedan trabajar juntos para lograr objetivos comunes [1].

## Quien lo impulsa
A2A (Agent2Agent) es impulsado por la comunidad de desarrolladores de IA y tecnología de inteligencia artificial [2]. El protocolo A2A es un estándar abierto, lo que significa que cualquier desarrollador puede contribuir y mejorar el protocolo [2]. La comunidad de A2A trabaja para hacer que el protocolo sea más seguro, escalable y fácil de usar [2].

## Como funciona
El protocolo A2A funciona delegando tareas entre frameworks [1]. Los agentes de IA se comunican entre sí y pueden delegar tareas a otros agentes que tengan la capacidad de realizarlas [1]. Esto permite que los agentes de IA trabajen juntos para lograr objetivos comunes de manera eficiente y segura [1]. El protocolo A2A también permite que los agentes de IA se descubran y colaboren entre sí [3].

## A2A vs MCP
A2A (Agent2Agent) se diferencia de MCP (Multi-Cloud Platform) en que A2A es un protocolo de comunicación entre agentes de IA, mientras que MCP es una plataforma de nube que permite la integración de diferentes servicios y aplicaciones [2]. A2A es un estándar abierto, mientras que MCP es una plataforma propietaria [2]. A2A permite la delegación de tareas entre frameworks, mientras que MCP se enfoca en la integración de servicios y aplicaciones [2].

**Referencias:**

[1] Protocolo Agent2Agent: Seguridad A2A, arquitectura y comparación con MCP (https://www.openlegion.ai/es/learn/agent2agent-protocol)
[2] ¿Qué es A2A? El protocolo entre agentes frente a MCP (https://arte.itlibra.com/es/articles/what-is-a2a-protocol)
[3] Qué es el protocolo A2A (Agent2Agent) y cuándo lo necesitas (https://blog.shakersworks.com/que-es-el-protocolo-a2a)