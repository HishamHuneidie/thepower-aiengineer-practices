"""Ejercicio 1 (basico) · Un equipo de 2 agentes en secuencia con LangGraph: investigador -> redactor.

Sin supervisor: el orden lo fijan las aristas (patron SECUENCIAL). El handoff es el estado comun:
el investigador deja "fuentes" y el redactor las lee.
Ejecutar desde la raiz del repo:  python soluciones/ejercicio1_dos_agentes.py
"""
import sys
import time
from pathlib import Path
from typing import TypedDict

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))     # para importar comun.py de la raiz

from langchain_ollama import ChatOllama                          # noqa: E402
from langgraph.graph import END, START, StateGraph               # noqa: E402

from comun import MODELO, buscar_web, formatear_fuentes          # noqa: E402

TEMA = "la semana laboral de 4 dias en Espana: en que consiste, donde se ha probado y que resultados ha dado"
llm = ChatOllama(model=MODELO, temperature=0, num_predict=400)


class Estado(TypedDict, total=False):
    tema: str
    fuentes: list      # lo escribe el investigador
    resumen: str       # lo escribe el redactor


def investigador(e: Estado) -> Estado:
    """Rol 1: buscar. No usa el LLM: dos busquedas fijas bastan para un tema sencillo."""
    fuentes = []
    for consulta in (f"{e['tema']}", "semana laboral 4 dias Espana resultados piloto"):
        fuentes += [f for f in buscar_web(consulta, n=3) if f["url"] not in {x["url"] for x in fuentes}]
    print(f"INVESTIGADOR · {len(fuentes)} fuentes")
    return {"fuentes": fuentes}


def redactor(e: Estado) -> Estado:
    """Rol 2: escribir, SOLO con lo que dejo el investigador en el estado."""
    texto = llm.invoke("Escribe en espanol un resumen de 5 lineas sobre el TEMA usando SOLO las FUENTES. "
                       "Cita cada dato con su numero de fuente entre corchetes, por ejemplo [2].\n"
                       f"TEMA: {e['tema']}\nFUENTES:\n{formatear_fuentes(e['fuentes'])}").content.strip()
    print("REDACTOR · resumen escrito")
    return {"resumen": texto}


g = StateGraph(Estado)
g.add_node("investigador", investigador)
g.add_node("redactor", redactor)
g.add_edge(START, "investigador")
g.add_edge("investigador", "redactor")     # el handoff: siempre en el mismo orden
g.add_edge("redactor", END)
equipo = g.compile()

if __name__ == "__main__":
    t0 = time.time()
    r = equipo.invoke({"tema": TEMA})
    print("\n=== RESUMEN\n" + r["resumen"])
    print("\nFUENTES")
    for i, f in enumerate(r["fuentes"], 1):
        print(f"[{i}] {f['titulo']} · {f['url']}")
    print(f"\n({round(time.time() - t0)} s, 1 llamada al LLM)")
    print("\nFramework: LangGraph. Por que: con dos agentes en secuencia bastan dos nodos y una arista,\n"
          "y el estado comun deja ver exactamente que le pasa el investigador al redactor.")
