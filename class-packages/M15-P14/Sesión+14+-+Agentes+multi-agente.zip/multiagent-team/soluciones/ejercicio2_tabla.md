# Ejercicio 2 · Equipo de soporte: LangGraph vs CrewAI

Mensaje de prueba: *"Hola, el pedido 1234 me ha llegado roto. ¿Cómo lo devuelvo? Y el 5678, ¿cuándo llega?"*

| | LangGraph (`ejercicio2_soporte_langgraph.py`) | CrewAI (`ejercicio2_soporte_crewai.py`) |
|---|---|---|
| Patrón | supervisor que elige trabajador y le pasa un **encargo** | secuencial: pedidos → devoluciones → coordinador |
| Control | total: nadie trabaja dos veces, tope de turnos, encargo por trabajador | `max_iter`, `context` y el orden de las tareas |
| Rapidez de desarrollo | más código (grafo, estado, supervisor) | menos código: agentes y tareas |
| Coste | 1 llamada del supervisor por turno + 2 por trabajador + 1 final | prompts más largos (rol, historia, formato ReAct) |
| Ejecutado en clase | sí: 142 s en CPU con llama3.1 | no (en CPU, CrewAI tarda varias veces más) |

**Lo que salió en clase (LangGraph).** Primera versión: cada trabajador recibía el mensaje entero, contestaba de
todo e inventaba (el de devoluciones dijo que el 5678 estaba "en tránsito, 3-5 días"). Con el encargo, cada uno
responde solo a su parte y el de pedidos acierta. Pero el encargo de devoluciones fue "¿Cómo lo devuelvo?": se
perdió "roto" y la herramienta aplicó la política normal (4,95 €) en vez de la gratuita por producto dañado.

**Lección:** lo que viaja en el handoff importa tanto como quién lo recibe. Mejora propuesta: que el encargo
incluya siempre el número de pedido y el motivo, o pasar el mensaje completo como contexto además del encargo.
