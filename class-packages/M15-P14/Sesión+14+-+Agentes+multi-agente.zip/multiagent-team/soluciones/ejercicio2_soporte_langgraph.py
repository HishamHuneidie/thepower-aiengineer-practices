"""Ejercicio 2 (reto) · El agente de pedidos de la Sesion 2 convertido en un EQUIPO, version LangGraph.

supervisor -> agente de pedidos (tool consulta_pedido) / agente de devoluciones (tool politica_devolucion)
           -> redactor final que junta las respuestas en un solo mensaje al cliente.
La version CrewAI esta en ejercicio2_soporte_crewai.py y la tabla comparativa en ejercicio2_tabla.md.
Ejecutar desde la raiz del repo:  python soluciones/ejercicio2_soporte_langgraph.py
"""
import json
import time
from typing import TypedDict

from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama
from langgraph.graph import END, START, StateGraph

PEDIDOS = {   # la base de datos de juguete de la Sesion 2
    "1234": {"estado": "entregado", "transportista": "SEUR", "llegada": "entregado el lunes"},
    "5678": {"estado": "en preparacion", "transportista": "-", "llegada": "la semana que viene"},
}


@tool
def consulta_pedido(numero: str) -> dict:
    """Devuelve el estado, el transportista y la fecha de llegada de un pedido a partir de su numero."""
    return PEDIDOS.get(numero, {"error": f"No existe el pedido {numero}"})


@tool
def politica_devolucion(motivo: str) -> str:
    """Explica como devolver un pedido segun el motivo (roto, talla, no me gusta...)."""
    if "rot" in motivo.lower() or "defect" in motivo.lower():
        return "Producto danado: devolucion gratis en 30 dias, con foto del dano, y envio de uno nuevo sin coste."
    return "Devolucion en 14 dias desde la entrega; el envio de vuelta cuesta 4,95 EUR."


llm = ChatOllama(model="llama3.1", temperature=0, num_predict=300)
juez = ChatOllama(model="llama3.1", temperature=0, format="json", num_predict=150)
MAX_TURNOS = 5


class Estado(TypedDict, total=False):
    mensaje: str
    respuestas: dict      # {"pedidos": "...", "devoluciones": "..."}: la memoria compartida del equipo
    siguiente: str
    encargo: str          # el HANDOFF: la parte del mensaje que le toca al siguiente trabajador
    turnos: int
    final: str


def agente_con_tool(rol: str, especialidad: str, herramienta, pregunta: str) -> str:
    """Un trabajador: el modelo pide la tool, el codigo la ejecuta y el modelo contesta con el resultado."""
    modelo = llm.bind_tools([herramienta])
    msgs = [SystemMessage(f"Eres el {rol} de una tienda online ({especialidad}). Responde en espanol, breve, "
                          "usando tu herramienta y sin inventar nada que no te diga la herramienta."),
            HumanMessage(pregunta)]
    ai = modelo.invoke(msgs)
    for c in ai.tool_calls:
        msgs += [ai, ToolMessage(json.dumps(herramienta.invoke(c["args"]), ensure_ascii=False), tool_call_id=c["id"])]
    return llm.invoke(msgs).content.strip() if ai.tool_calls else ai.content.strip()


def supervisor(e: Estado) -> Estado:
    turnos = e.get("turnos", 0) + 1
    hechos = list(e.get("respuestas", {}))
    r = json.loads(juez.invoke(
        "Eres el supervisor de soporte. Trabajadores: 'pedidos' (estado y envio de pedidos) y 'devoluciones' "
        "(como devolver). Segun el MENSAJE, elige el siguiente trabajador que aun NO haya respondido, o 'FIN' si "
        'ya estan todos los necesarios. En "encargo" copia SOLO la frase del mensaje que le toca a ese trabajador. '
        'Responde SOLO con JSON: {"siguiente": "pedidos|devoluciones|FIN", "encargo": "..."}\n'
        f"MENSAJE: {e['mensaje']}\nYA HAN RESPONDIDO: {hechos or 'nadie'}").content)
    sig = r.get("siguiente", "FIN")
    if sig in hechos or turnos > MAX_TURNOS or sig not in ("pedidos", "devoluciones"):
        sig = "FIN"          # barandilla: nadie trabaja dos veces y hay tope de turnos
    encargo = r.get("encargo") or e["mensaje"]
    print(f"SUPERVISOR · -> {sig}" + (f"  encargo: '{encargo}'" if sig != "FIN" else ""))
    return {"siguiente": sig, "encargo": encargo, "turnos": turnos}


def pedidos(e: Estado) -> Estado:
    txt = agente_con_tool("agente de pedidos", "el estado y la llegada de los pedidos", consulta_pedido, e["encargo"])
    print(f"PEDIDOS · {txt}")
    return {"respuestas": {**e.get("respuestas", {}), "pedidos": txt}}


def devoluciones(e: Estado) -> Estado:
    txt = agente_con_tool("agente de devoluciones", "como devolver un producto", politica_devolucion, e["encargo"])
    print(f"DEVOLUCIONES · {txt}")
    return {"respuestas": {**e.get("respuestas", {}), "devoluciones": txt}}


def redactar(e: Estado) -> Estado:
    notas = "\n".join(f"- {k}: {v}" for k, v in e.get("respuestas", {}).items())
    txt = llm.invoke("Junta estas respuestas de tu equipo en UN mensaje amable al cliente, en espanol, "
                     f"de 3-4 frases, sin inventar nada. Escribe SOLO el mensaje.\nMENSAJE DEL CLIENTE: {e['mensaje']}\nEQUIPO:\n{notas}").content
    return {"final": txt.strip()}


g = StateGraph(Estado)
for n, f in (("supervisor", supervisor), ("pedidos", pedidos), ("devoluciones", devoluciones), ("redactar", redactar)):
    g.add_node(n, f)
g.add_edge(START, "supervisor")
g.add_conditional_edges("supervisor", lambda e: e["siguiente"],
                        {"pedidos": "pedidos", "devoluciones": "devoluciones", "FIN": "redactar"})
g.add_edge("pedidos", "supervisor")
g.add_edge("devoluciones", "supervisor")
g.add_edge("redactar", END)
equipo = g.compile()

if __name__ == "__main__":
    t0 = time.time()
    msg = "Hola, el pedido 1234 me ha llegado roto. ¿Como lo devuelvo? Y el 5678, ¿cuando llega?"
    print(f"CLIENTE: {msg}\n")
    r = equipo.invoke({"mensaje": msg})
    print(f"\n=== RESPUESTA AL CLIENTE\n{r['final']}\n\n({round(time.time() - t0)} s)")
