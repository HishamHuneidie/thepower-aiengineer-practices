"""Ejercicio 2 (reto) · El mismo equipo de soporte, version CrewAI (proceso secuencial).

pedidos -> devoluciones -> coordinador que escribe la respuesta final con el contexto de los dos.
Ejecutar desde la raiz del repo:  python soluciones/ejercicio2_soporte_crewai.py
"""
import json
import os
import time

os.environ.update({"CREWAI_TELEMETRY_OPT_OUT": "true", "OTEL_SDK_DISABLED": "true", "CREWAI_TRACING_ENABLED": "false"})

from crewai import LLM, Agent, Crew, Process, Task   # noqa: E402
from crewai.tools import tool                        # noqa: E402

PEDIDOS = {
    "1234": {"estado": "entregado", "transportista": "SEUR", "llegada": "entregado el lunes"},
    "5678": {"estado": "en preparacion", "transportista": "-", "llegada": "la semana que viene"},
}
llm = LLM(model="ollama/llama3.1", base_url="http://localhost:11434", temperature=0, max_tokens=300)


@tool("consulta_pedido")
def consulta_pedido(numero: str) -> str:
    """Devuelve el estado, el transportista y la fecha de llegada de un pedido a partir de su numero."""
    return json.dumps(PEDIDOS.get(numero, {"error": f"No existe el pedido {numero}"}), ensure_ascii=False)


@tool("politica_devolucion")
def politica_devolucion(motivo: str) -> str:
    """Explica como devolver un pedido segun el motivo (roto, talla, no me gusta...)."""
    if "rot" in motivo.lower() or "defect" in motivo.lower():
        return "Producto danado: devolucion gratis en 30 dias, con foto del dano, y envio de uno nuevo sin coste."
    return "Devolucion en 14 dias desde la entrega; el envio de vuelta cuesta 4,95 EUR."


agente_pedidos = Agent(role="Agente de pedidos", goal="Dar el estado real de los pedidos",
                       backstory="Consulta siempre el sistema antes de contestar.", tools=[consulta_pedido],
                       llm=llm, max_iter=3, allow_delegation=False)
agente_devol = Agent(role="Agente de devoluciones", goal="Explicar como devolver segun el motivo",
                     backstory="Conoce la politica de devoluciones y la consulta con su herramienta.",
                     tools=[politica_devolucion], llm=llm, max_iter=3, allow_delegation=False)
coordinador = Agent(role="Coordinador de soporte", goal="Responder al cliente en un solo mensaje amable",
                    backstory="Junta lo que dice el equipo sin inventar nada.", llm=llm, allow_delegation=False)

t_ped = Task(description="Mensaje del cliente: {mensaje} Consulta los pedidos que menciona.",
             expected_output="Estado y fecha de cada pedido mencionado.", agent=agente_pedidos)
t_dev = Task(description="Mensaje del cliente: {mensaje} Si quiere devolver algo, explica como segun el motivo.",
             expected_output="Pasos de la devolucion, o 'no aplica'.", agent=agente_devol)
t_fin = Task(description="Escribe la respuesta final al cliente ({mensaje}) en espanol, 3-4 frases.",
             expected_output="El mensaje al cliente y nada mas.", agent=coordinador, context=[t_ped, t_dev])

if __name__ == "__main__":
    t0 = time.time()
    msg = "Hola, el pedido 1234 me ha llegado roto. ¿Como lo devuelvo? Y el 5678, ¿cuando llega?"
    crew = Crew(agents=[agente_pedidos, agente_devol, coordinador], tasks=[t_ped, t_dev, t_fin],
                process=Process.sequential)
    r = crew.kickoff(inputs={"mensaje": msg})
    print(f"CLIENTE: {msg}\n\n=== RESPUESTA AL CLIENTE\n{r.raw}\n\n"
          f"({round(time.time() - t0)} s, {r.token_usage.successful_requests} llamadas al LLM)")
