# multiagent-team · Sesión 9 · Equipos multi-agente: LangGraph vs CrewAI

Material de la práctica de la Sesión 9 del Master AI Engineer. Una misma tarea de varias fases
(**investigar el protocolo A2A y escribir un resumen estructurado con citas**) resuelta de tres formas:

| Paso | Fichero | Qué es |
|---|---|---|
| 1 | `01_agente_unico.py` | Un solo agente con una herramienta de búsqueda (el patrón de la Sesión 2) |
| 2 | `02_equipo_langgraph.py` | Equipo con LangGraph: supervisor + investigador + redactor + revisor |
| 3 | `03_equipo_crewai.py` | El mismo equipo con CrewAI (`--jerarquico` para el modo con manager) |
| 4 | `04_comparar.py` | Tabla LangGraph vs CrewAI con lo medido en las ejecuciones (no llama al LLM) |

`comun.py` guarda lo que comparten todos: la tarea, el formato pedido, la búsqueda web (DuckDuckGo, la
misma del deep research de la Sesión 7) y cómo puntuamos el informe (secciones presentes y citas).
Las salidas reales de clase están en `salidas/`.

## Cómo ejecutarlo

```bash
ollama pull llama3.1          # si no lo tienes de sesiones anteriores
python -m venv .venv
.venv\Scripts\activate        # Windows
pip install -r requirements.txt
python 01_agente_unico.py
python 02_equipo_langgraph.py
python 03_equipo_crewai.py
python 04_comparar.py
```

Todo es local y gratis: Ollama + DuckDuckGo, sin claves ni `.env`. En CPU cada llamada al LLM tarda
de 20 s a 1 min, así que un equipo completo son varios minutos.

## Conceptos

**Patrones de coordinación**
- **Supervisor**: un agente jefe decide a quién pasa el trabajo y cuándo se acaba. Los trabajadores no
  hablan entre sí. Es el del paso 2 (y el modo `--jerarquico` de CrewAI).
- **Jerárquico**: equipos de equipos; un supervisor de supervisores. Se construye anidando grafos.
- **Secuencial**: cadena de montaje, la salida de uno es la entrada del siguiente. Es el proceso por
  defecto de CrewAI (paso 3) y el del ejercicio 1.

**Handoff**: el momento en que un agente termina y pasa el control a otro. En LangGraph es una arista
(todos los trabajadores vuelven al supervisor, y el supervisor elige con una arista condicional). En
CrewAI es el `context=[...]` de una tarea o la herramienta de delegar del manager.

**Memoria compartida**: el estado común. En LangGraph es el `TypedDict Estado`: el investigador escribe
`fuentes`, el redactor escribe `borrador`, el revisor escribe `revision`, y el supervisor lo lee todo.
En CrewAI es la salida de cada tarea, que se pasa a las siguientes.

**Barandillas**: un supervisor que es un LLM de 8B se equivoca. En `02_equipo_langgraph.py` el código
comprueba cada decisión (no se redacta sin fuentes, no se acaba sin revisar, como mucho una reescritura
y un tope de turnos). Eso es el "control total" de LangGraph.

## LangGraph vs CrewAI

| | LangGraph | CrewAI |
|---|---|---|
| Lo defines con | nodos, aristas y estado | roles, objetivos y tareas |
| Quién decide el orden | tú (o tu supervisor, con tus reglas) | el framework |
| Control del flujo | total | limitado (`max_iter`, `context`, tipo de proceso) |
| Depurar | el rastro que tú escribes | el log `verbose` |
| Montarlo | más lento | muy rápido |
| Lo elegiría para | producción, flujos con reglas de negocio | prototipos y equipos por roles |

Los números reales (líneas de código, llamadas al LLM, segundos, formato y citas) los imprime
`python 04_comparar.py`.

## Ejercicios

- `soluciones/ejercicio1_dos_agentes.py`: básico. Dos agentes en secuencia (investigador → redactor).
- `soluciones/ejercicio2_soporte_langgraph.py` y `soluciones/ejercicio2_soporte_crewai.py`: reto. El
  agente de pedidos de la Sesión 2 convertido en un equipo de soporte (pedidos + devoluciones + quien
  responde al cliente) en los dos frameworks, con la comparativa en `soluciones/ejercicio2_tabla.md`.
