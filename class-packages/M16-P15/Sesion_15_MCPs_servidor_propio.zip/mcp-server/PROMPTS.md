# Sesión 10 · MCPs: construye tu propio servidor MCP · Prompts para Claude Code

Estos son los prompts que usamos en la práctica, en el mismo orden que en clase. Cópialos y pégalos en Claude Code uno a uno.

**Cómo usarlos**
1. Pega el prompt del paso y deja que Claude Code proponga los cambios.
2. **Lee el código antes de aceptar** (y los comandos, como `pip install`, antes de permitirlos).
3. Ejecuta y compara con el apartado *Qué deberías ver*.
4. Si no sale lo esperado, vuelve a pedírselo con lo que has aprendido.

> Antes de empezar: Python 3.10 o superior, [uv](https://docs.astral.sh/uv/) instalado y Claude Code. No hace falta ninguna clave ni cuenta: todo es local por STDIO y las APIs que usamos (Frankfurter y Open-Meteo) son públicas y gratuitas. Solo el paso 5 usa Ollama con `llama3.1` (Sesión 1). Abre Claude Code en una carpeta vacía.

El resultado de referencia, con todo el código comentado, está en la carpeta `mcp-server` del material de la sesión.

---

## Paso 1 · Montar el proyecto y el esqueleto

**Qué construye**

- uv init: carpeta + pyproject.toml
- uv add "mcp[cli]": el SDK oficial
- server.py con la instancia del servidor
- Arranca por STDIO, todavia sin tools

**Prompt**

```text
Inicia un proyecto MCP con uv: crea la carpeta, el entorno virtual y anade la dependencia mcp[cli] (y httpx). Luego crea server.py con la instancia basica de un servidor MCP llamado 'mi-servidor', importando lo necesario del SDK oficial de Python. Comprueba antes que version de mcp se ha instalado: en la 2.x la clase es MCPServer (from mcp.server.mcpserver import MCPServer), en la 1.x era FastMCP. Configura logging a stderr y explica cada linea con un comentario didactico para que un principiante lo entienda.
```

**Qué deberías ver**

Mcp 2.2.0: la version importa. En la 2.x la clase ya no se llama FastMCP, se llama MCPServer.

---

## Paso 2 · Tu primera tool con @mcp.tool()

**Qué construye**

- Una funcion async con type hints
- Docstring: que hace y cada parametro
- Llama a Frankfurter (tipos del BCE)
- tools/list y tools/call desde el cliente

**Prompt**

```text
Anade a server.py una primera tool decorada con @mcp.tool(): una funcion asincrona convertir_precio(importe_eur: float, moneda: str) con un docstring claro que describa que hace y sus parametros. Que consulte la API publica y sin clave de Frankfurter (https://api.frankfurter.dev/v1/latest?from=EUR&to=USD) con httpx asincrono. Recuerda que el SDK genera la definicion de la tool a partir del docstring y los type hints. Pruebala con un cliente que haga initialize, tools/list y tools/call y ensene cada mensaje JSON-RPC. Explicame por que el docstring es tan importante.
```

**Qué deberías ver**

49,90 EUR = 42,91 GBP con el tipo real del BCE de ayer. La tool funciona antes de conectar ningun LLM.

### Variación en vivo: Variación · descripciones y limites dentro del esquema

```text
Crea extras/02_descripciones.py con la misma tool convertir_precio pero usando Annotated y pydantic.Field: importe_eur con gt=0 y description, y moneda como Literal['USD','GBP','JPY','CHF','MXN','BRL'] con description. Ensename con el cliente el inputSchema que se genera ahora y que pasa si la llamo con importe -5 y moneda EUR.
```

**Qué demuestra**

Cada parametro trae su descripcion, un minimo y un enum. Y la validacion la hace el SDK: -5 y 'EUR' se rechazan con isError: true sin tocar tu codigo.

---

## Paso 3 · Conectar el servidor a Claude Code (STDIO)

**Qué construye**

- claude mcp add: nombre + command + args
- El host arranca server.py como subproceso
- claude mcp list: comprueba que conecta
- Dentro de Claude Code: /mcp

**Prompt**

```text
Configura este servidor MCP para conectarlo a Claude Code por transporte STDIO: dame el comando claude mcp add con el command (el python del .venv o uv run) y los args, y el bloque equivalente de .mcp.json. Explica la diferencia entre scope local y scope project, como compruebo con claude mcp list que conecta y como veo la tool con /mcp dentro de Claude Code. Recuerdame la regla de no usar print() en STDIO y usar logging a stderr, y por que.
```

**Qué deberías ver**

✔ Connected: Claude Code arranca el servidor, hace el handshake y lo da por bueno.

### Variación en vivo: Variación · el error numero uno: un print() en stdout

```text
Crea extras/03_con_print.py: un servidor minimo con una tool saludar(nombre) y un print('Servidor listo!', flush=True) antes de mcp.run(). Lanzalo con el cliente JSON-RPC y ensename que llega por stdout y por que se rompe. Explica tambien que hace el SDK 2.x con los print() que ocurren DENTRO de una tool.
```

**Qué demuestra**

El cliente recibe 'Servidor listo!' donde esperaba JSON. Y todo se desincroniza: a tools/list le llega la respuesta del id 1.

---

## Paso 4 · Añadir un resource y una segunda tool

**Qué construye**

- Resource: politica de devoluciones por URI
- Tool: consultar_pedido (la de la Sesion 2)
- Validar entradas: 4 cifras, moneda soportada
- Errores con mensaje util para el modelo

**Prompt**

```text
Amplia el servidor: anade un resource de solo lectura tienda://politica-devoluciones que devuelva el contenido de datos/politica_devoluciones.txt, y una segunda tool consultar_pedido(numero) con los pedidos 1234 y 5678 de la Sesion 2 (estado, transportista, llegada e importe en euros). Valida los parametros (4 cifras, moneda soportada, importe positivo) y devuelve errores con mensajes claros en lugar de lanzar excepciones. Pruebalo todo con el cliente y comenta la diferencia entre un resource (leer datos) y una tool (ejecutar una accion).
```

**Qué deberías ver**

Resources/list trae uri, nombre y mimeType; resources/read devuelve el texto tal cual.

---

## Paso 5 · Probar de punta a punta y empaquetar

**Qué construye**

- host_ollama.py: un host MCP en ~50 lineas
- tools/list -> se las damos a llama3.1
- Si pide una tool -> tools/call al servidor
- README: instalar, conectar, extender

**Prompt**

```text
Prueba el servidor de punta a punta. Crea host_ollama.py: un host MCP minimo que arranque server.py por STDIO con el Client del SDK, pida tools/list, pase esas definiciones a llama3.1 en Ollama como herramientas (el inputSchema es el formato de function calling), ejecute con tools/call las que pida el modelo y le devuelva el resultado, con un tope de 4 vueltas. Pruebalo con 'Cuando llega mi pedido 1234 y cuanto es su importe en dolares?'. Revisa que el logging va a stderr y escribe un README que explique como instalar, arrancar y conectar el servidor, que tools y resources expone y como extenderlo.
```

**Qué deberías ver**

Acerto con consultar_pedido... pero se olvido de los dolares. Contesto solo en euros.

### Variación en vivo: Variación · una tool pensada para la tarea

```text
Crea extras/server_tarea.py que reutilice el servidor y anada una tool importe_pedido_en(numero, moneda) que consulte el pedido y convierta su importe en una sola llamada. Lanza host_ollama.py con --servidor extras/server_tarea.py y la misma pregunta, y explicame que tool elige el modelo y por que.
```

**Qué demuestra**

Llama3.1 la ignoro y repitio el error. Con un modelo de 8B, mas tools = mas confusion. Disena pocas tools, claras, y valida siempre.

---

## Ejercicio 1 · Construye tu propio servidor MCP

**Qué construye**

- Proyecto con uv + mcp[cli]
- Una tool con buen docstring
- Conectala por STDIO
- Comprueba tools/list y usala

**Prompt**

```text
Crea con uv un proyecto con mcp[cli] y httpx y un servidor MCP 'tiempo' (SDK oficial, MCPServer, transporte STDIO) con una tool tiempo_actual(ciudad) que consulte la API publica y sin clave de Open-Meteo para Madrid, Barcelona, Sevilla, Valencia o Bilbao y devuelva la temperatura y el viento actuales. Buen docstring, logging a stderr y un mensaje claro si la ciudad no esta soportada. Conectalo a Claude Code con claude mcp add y dime como compruebo que aparece con tools/list.
```

**Qué deberías ver**

La temperatura y el viento reales de la ciudad, y un error util para una ciudad no soportada.

---

## Ejercicio 2 · Reto: 2 tools + 1 resource conectados a Claude Code

**Qué construye**

- Un dominio tuyo
- 2 tools (una con efectos)
- 1 resource por URI
- Conectado + README

**Prompt**

```text
Construye un servidor MCP en Python (SDK oficial, MCPServer, STDIO) para un cuaderno de notas guardado en notas.json: una tool guardar_nota(titulo, texto) que valide longitudes y escriba en disco, una tool buscar_notas(palabra) que exija al menos 3 letras, y un resource notas://todas de solo lectura con todas las notas. Logging a stderr en cada operacion. Conectalo a Claude Code, pruebalo guardando y buscando una nota y escribe un README que explique como instalarlo, conectarlo y extenderlo.
```

**Qué deberías ver**

La nota guardada, el error del titulo vacio, la busqueda y el resource con todas las notas.

---

*Material del Master AI Engineer · The Power · Ignacio de Pastors*
