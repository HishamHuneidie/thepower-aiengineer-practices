"""Paso 2 · Primera tool con @mcp.tool(): convertir un precio con una API publica sin clave."""
import logging
import sys

import httpx
from mcp.server.mcpserver import MCPServer

logging.basicConfig(stream=sys.stderr, level=logging.INFO, format="[mi-servidor] %(levelname)s %(message)s")
mcp = MCPServer("mi-servidor")


@mcp.tool()  # el decorador registra la funcion: nombre + docstring + type hints -> definicion de la tool
async def convertir_precio(importe_eur: float, moneda: str) -> str:
    """Convierte un importe en euros a otra moneda con el tipo de cambio oficial del BCE de hoy.

    Args:
        importe_eur: cantidad en euros, por ejemplo 49.90
        moneda: codigo ISO de la moneda destino, por ejemplo USD o GBP
    """
    url = f"https://api.frankfurter.dev/v1/latest?from=EUR&to={moneda.upper()}"
    async with httpx.AsyncClient(timeout=10) as cliente:   # async: no bloquea el servidor mientras espera la red
        datos = (await cliente.get(url)).json()
    tipo = datos["rates"][moneda.upper()]
    return f"{importe_eur:.2f} EUR = {importe_eur * tipo:.2f} {moneda.upper()} (tipo {tipo}, BCE {datos['date']})"


if __name__ == "__main__":
    mcp.run()
