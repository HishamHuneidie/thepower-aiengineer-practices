"""Paso 1 · Esqueleto: un servidor MCP que arranca por STDIO, todavia sin tools."""
import logging
import sys

# mcp 2.x: MCPServer (en la 1.x se llamaba FastMCP y se importaba de mcp.server.fastmcp)
from mcp.server.mcpserver import MCPServer

# Todo lo que no sea JSON-RPC va a stderr: stdout es el canal del protocolo
logging.basicConfig(stream=sys.stderr, level=logging.INFO, format="[mi-servidor] %(levelname)s %(message)s")

# La instancia del servidor. El nombre es como lo vera el host (Claude Code, VS Code...)
mcp = MCPServer("mi-servidor")

if __name__ == "__main__":
    logging.info("arrancando por STDIO (sin tools todavia)...")
    mcp.run()  # por defecto transport="stdio": lee de stdin, responde por stdout
