"""Variacion en vivo (paso 3): el error numero uno. Un print() de depuracion rompe el servidor STDIO."""
from mcp.server.mcpserver import MCPServer

mcp = MCPServer("mi-servidor")


@mcp.tool()
def saludar(nombre: str) -> str:
    """Saluda a una persona por su nombre."""
    return f"Hola, {nombre}"


if __name__ == "__main__":
    print("Servidor listo!", flush=True)   # <- MAL: sale por stdout, el canal del JSON-RPC
    mcp.run()

# Nota (mcp 2.x): mientras mcp.run() esta activo, el SDK desvia stdout a stderr, asi que un print()
# DENTRO de una tool ya no rompe el protocolo. Pero un print que sale antes (o desde otro proceso,
# una libreria en C, u otro SDK/version) si llega al canal. La regla sigue: logging a stderr.
