"""Variacion en vivo (paso 2): descripciones POR PARAMETRO dentro del JSON Schema.

El SDK no convierte la seccion Args: del docstring en descripciones de cada parametro;
con Annotated + Field(description=...) si aparecen en el inputSchema, que es lo que lee el modelo.
"""
from typing import Annotated, Literal

from mcp.server.mcpserver import MCPServer
from pydantic import Field

mcp = MCPServer("mi-servidor")


@mcp.tool()
async def convertir_precio(
    importe_eur: Annotated[float, Field(gt=0, description="Cantidad en euros, por ejemplo 49.90")],
    moneda: Annotated[Literal["USD", "GBP", "JPY", "CHF", "MXN", "BRL"], Field(description="Moneda destino (ISO)")],
) -> str:
    """Convierte un importe en euros a otra moneda con el tipo de cambio oficial del BCE de hoy."""
    return "(ejemplo: solo miramos la definicion que genera el SDK)"


if __name__ == "__main__":
    mcp.run()
