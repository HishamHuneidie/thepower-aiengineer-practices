# mi-servidor · Sesión 10: construye tu propio servidor MCP

Servidor MCP en Python (SDK oficial `mcp` 2.x, transporte **STDIO**) para la tienda online de la Sesión 2.
Todo local y gratis: sin claves ni cuentas.

| Primitiva | Nombre | Qué hace |
|---|---|---|
| Tool | `convertir_precio(importe_eur, moneda)` | Convierte euros con el tipo oficial del BCE (API pública [Frankfurter](https://frankfurter.dev), sin clave) |
| Tool | `consultar_pedido(numero)` | Estado, transportista, llegada e importe de los pedidos 1234 y 5678 (los de la Sesión 2), con validación |
| Resource | `tienda://politica-devoluciones` | La política de devoluciones (`datos/politica_devoluciones.txt`), solo lectura |

## Instalar

```bash
uv sync                      # crea .venv e instala mcp[cli] y httpx
```

> **Ojo con la versión:** en `mcp` 2.x la clase es `MCPServer` (`from mcp.server.mcpserver import MCPServer`).
> El código de muchos tutoriales usa `FastMCP` de `mcp.server.fastmcp`, que es la 1.x y falla con la 2.x.
> En redes corporativas, si `uv` falla con `HandshakeFailure`, prueba `UV_NATIVE_TLS=1` o el índice de paquetes de tu empresa.

## Probarlo sin ningún LLM

`cliente_jsonrpc.py` arranca un servidor por STDIO y enseña cada mensaje JSON-RPC (initialize → list → call):

```bash
uv run python cliente_jsonrpc.py server.py list resources read tienda://politica-devoluciones
uv run python cliente_jsonrpc.py server.py call convertir_precio '{"importe_eur": 49.9, "moneda": "USD"}'
uv run python cliente_jsonrpc.py server.py call consultar_pedido '{"numero": "1234"}'
```

## Conectarlo a Claude Code

```bash
claude mcp add --scope local mi-servidor -- C:/ruta/a/mcp-server/.venv/Scripts/python.exe C:/ruta/a/mcp-server/server.py
claude mcp list              # debe decir: ✔ Connected
```

Dentro de Claude Code, `/mcp` muestra el servidor y sus tools; el resource se añade con `@mi-servidor`.
Para compartirlo con el equipo usa `--scope project` (escribe `.mcp.json`; Claude Code pedirá aprobarlo). Tienes un ejemplo con `uv run` en `mcp.json.ejemplo`.
Usa **rutas absolutas**.

**Regla de oro de STDIO:** stdout es el canal del protocolo. Nunca `print()`: usa `logging` a **stderr** (ver `extras/03_con_print.py`).

## Estructura

```
pasos/01_esqueleto.py        Paso 1 · servidor que arranca, sin tools
pasos/02_primera_tool.py     Paso 2 · primera tool (convertir_precio)
server.py                    Pasos 3-5 · servidor completo: 2 tools + 1 resource + logging
cliente_jsonrpc.py           Cliente "a pelo" que enseña los mensajes JSON-RPC
host_ollama.py               Paso 5 · un host MCP mínimo con llama3.1 (Ollama)
extras/02_descripciones.py   Variación · Annotated + Field + Literal: descripciones y validación en el esquema
extras/03_con_print.py       Variación · un print() que rompe el protocolo
extras/server_tarea.py       Variación · una tool pensada para la tarea (importe_pedido_en)
soluciones/ej1_tiempo.py     Ejercicio 1 · una tool con Open-Meteo (sin clave)
soluciones/ej2_notas.py      Ejercicio 2 · 2 tools + 1 resource (cuaderno de notas)
salidas/                     Salidas reales de las ejecuciones de clase
```

## Cómo extenderlo

1. Añade una función con `@mcp.tool()`: nombre claro, type hints y un docstring que diga qué hace y cuándo usarla.
2. Usa `Annotated[..., Field(description=..., gt=...)]` y `Literal[...]` para que cada parámetro tenga descripción y límites.
3. Valida lo que entra y devuelve errores que expliquen cómo arreglarlo (el modelo los lee y puede corregirse).
4. Datos de solo lectura → `@mcp.resource("esquema://direccion")`. Acciones o búsquedas con parámetros → tool.

## Lo que vimos en clase (ejecuciones reales)

- `host_ollama.py` con llama3.1: consultó el pedido pero **no encadenó** la conversión a dólares.
- Con un system prompt más explícito pidió las dos tools **en paralelo** e inventó `importe_eur = "importe en euros"`: la validación del esquema lo paró.
- Con la tool `importe_pedido_en` (extras) repitió el error: con un modelo de 8B, pocas tools y muy claras.
- No ejecutado en clase: probar `server_tarea.py` dejando solo la tool `importe_pedido_en`.
