import importlib.util, importlib.metadata, subprocess, sys
faltan = [p for p in ("peft", "bitsandbytes", "datasets", "accelerate") if importlib.util.find_spec(p) is None]
if faltan:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", *faltan], check=False)
# Colab trae de serie una version antigua de torchao que hace fallar a peft al fusionar el adapter. No la usamos: fuera.
try:
    v = importlib.metadata.version("torchao")
    if tuple(int(x) for x in v.split(".")[:2]) < (0, 16):
        subprocess.run([sys.executable, "-m", "pip", "uninstall", "-y", "-q", "torchao"], check=False)
        print(f"torchao {v} desinstalado (incompatible con peft)")
except importlib.metadata.PackageNotFoundError:
    pass
print("Librerias listas")

EJEMPLOS = [
 {
  "instruccion": "¿Dónde está mi pedido?",
  "respuesta": "Estimado cliente, puede consultar el estado de su pedido en el apartado Mis pedidos de su cuenta, donde encontrará el número de seguimiento.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "quiero devolver unas zapatillas",
  "respuesta": "Estimado cliente, puede solicitar la devolución desde Mis pedidos durante los 30 días posteriores a la entrega; le enviaremos una etiqueta de envío.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "me ha llegado roto el paquete",
  "respuesta": "Estimado cliente, lamentamos lo ocurrido. Le rogamos que nos envíe una fotografía del producto y del embalaje para gestionar la reposición.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "cuanto tarda el envio",
  "respuesta": "Estimado cliente, los envíos estándar se entregan en un plazo de 24 a 48 horas laborables desde la confirmación del pedido.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "puedo cambiar la direccion de entrega?",
  "respuesta": "Estimado cliente, puede modificar la dirección mientras el pedido no haya salido del almacén, desde el apartado Mis pedidos.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "no me ha llegado el reembolso",
  "respuesta": "Estimado cliente, los reembolsos se realizan en un plazo de 5 a 7 días laborables desde que recibimos la devolución. Si ha transcurrido ese plazo, le rogamos que nos lo indique.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "tenéis tienda física?",
  "respuesta": "Estimado cliente, por el momento operamos únicamente a través de nuestra tienda en línea.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "se puede pagar con bizum",
  "respuesta": "Estimado cliente, aceptamos pago con tarjeta, transferencia y Bizum en el último paso del proceso de compra.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "me habeis cobrado dos veces",
  "respuesta": "Estimado cliente, lamentamos las molestias. Le rogamos que nos facilite el número de pedido para revisar el cargo duplicado y proceder a su devolución.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "el descuento no funciona",
  "respuesta": "Estimado cliente, le rogamos que compruebe la fecha de validez del código y que su pedido cumpla el importe mínimo indicado en la promoción.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "hacéis envíos a portugal",
  "respuesta": "Estimado cliente, realizamos envíos a Portugal con un plazo de entrega de 3 a 5 días laborables.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "quiero cancelar mi pedido ya",
  "respuesta": "Estimado cliente, puede cancelar el pedido desde Mis pedidos mientras no haya sido enviado. Si ya ha salido, podrá devolverlo a su recepción.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "necesito factura",
  "respuesta": "Estimado cliente, puede descargar la factura de su pedido en formato PDF desde el apartado Mis pedidos.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "la talla me queda pequeña",
  "respuesta": "Estimado cliente, puede solicitar el cambio de talla desde Mis pedidos sin coste adicional, siempre que el producto no haya sido usado.\nAtentamente, Servicio de Atención al Cliente"
 },
 {
  "instruccion": "hay garantía?",
  "respuesta": "Estimado cliente, todos nuestros productos cuentan con una garantía legal de tres años desde la fecha de entrega.\nAtentamente, Servicio de Atención al Cliente"
 }
]
PRUEBA = ["oye mi paquete no llega", "quiero hablar con alguien ya", "me podéis regalar los gastos de envío?", "el producto no es como en la foto"]
FIRMA = "Atentamente, Servicio de Atención al Cliente"
import re

def es_formal(texto: str) -> bool:
    """Formal = sin tuteo, empieza por 'Estimado cliente' y termina con la firma."""
    t = texto.strip()
    tuteo = re.search(r"\b(tú|tu pedido|tienes|puedes|quieres|te |ti\b|vosotros|os )", t.lower())
    return t.startswith("Estimado cliente") and t.endswith(FIRMA) and not tuteo

print(len(EJEMPLOS), "ejemplos · todos formales:", all(es_formal(e["respuesta"]) for e in EJEMPLOS))
print("\nEjemplo:\n", EJEMPLOS[0]["respuesta"])

import time, torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

GPU = torch.cuda.is_available()
MODELO = "Qwen/Qwen2.5-1.5B-Instruct" if GPU else "HuggingFaceTB/SmolLM2-135M-Instruct"
print("GPU:", torch.cuda.get_device_name(0) if GPU else "no hay GPU -> MODO PRUEBA")
tok = AutoTokenizer.from_pretrained(MODELO); tok.pad_token = tok.pad_token or tok.eos_token
if GPU:
    from transformers import BitsAndBytesConfig
    q = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16)
    modelo = AutoModelForCausalLM.from_pretrained(MODELO, quantization_config=q, device_map="auto")
else:
    modelo = AutoModelForCausalLM.from_pretrained(MODELO)

def responder(m, pregunta):
    enc = tok.apply_chat_template([{"role": "user", "content": pregunta}], add_generation_prompt=True,
                                  return_tensors="pt", return_dict=True).to(m.device)
    with torch.no_grad():
        out = m.generate(**enc, max_new_tokens=120 if GPU else 30, do_sample=False, pad_token_id=tok.pad_token_id)
    return tok.decode(out[0][enc["input_ids"].shape[1]:], skip_special_tokens=True).strip()

preguntas = PRUEBA if GPU else PRUEBA[:1]
antes = {p: responder(modelo, p) for p in preguntas}
if GPU:
    modelo = prepare_model_for_kbit_training(modelo)
modelo = get_peft_model(modelo, LoraConfig(r=8, lora_alpha=16, lora_dropout=0.05, task_type="CAUSAL_LM",
                                           target_modules="all-linear")   # todas las capas lineales: aprende mejor el estilo)
modelo.print_trainable_parameters()

from datasets import Dataset
from transformers import Trainer, TrainingArguments, DataCollatorForSeq2Seq

def preparar(e):
    p = tok.apply_chat_template([{"role": "user", "content": e["instruccion"]}], add_generation_prompt=True, tokenize=False)
    c = tok.apply_chat_template([{"role": "user", "content": e["instruccion"]}, {"role": "assistant", "content": e["respuesta"]}], tokenize=False)
    n = len(tok(p, add_special_tokens=False)["input_ids"]); ids = tok(c, add_special_tokens=False)["input_ids"]
    return {"input_ids": ids, "attention_mask": [1] * len(ids), "labels": [-100] * n + ids[n:]}

ds = Dataset.from_list(EJEMPLOS).map(preparar, remove_columns=["instruccion", "respuesta"])
args = TrainingArguments(output_dir="ej1", num_train_epochs=12, per_device_train_batch_size=4, learning_rate=3e-4,
                         logging_steps=4 if GPU else 1, save_strategy="no", report_to="none", fp16=GPU,
                         max_steps=-1 if GPU else 2, optim="adamw_torch")
t0 = time.time()
Trainer(model=modelo, args=args, train_dataset=ds, data_collator=DataCollatorForSeq2Seq(tok, padding=True)).train()
print(f"Entrenamiento: {time.time() - t0:.0f} s")

modelo.eval()
despues = {p: responder(modelo, p) for p in preguntas}
print(f"Respuestas formales · BASE: {sum(map(es_formal, antes.values()))}/{len(preguntas)} · "
      f"AJUSTADO: {sum(map(es_formal, despues.values()))}/{len(preguntas)}\n")
for p in preguntas:
    print("=" * 80, "\nPREGUNTA:", p)
    print("-- BASE ----------\n" + antes[p])
    print("-- AJUSTADO ------\n" + despues[p])
