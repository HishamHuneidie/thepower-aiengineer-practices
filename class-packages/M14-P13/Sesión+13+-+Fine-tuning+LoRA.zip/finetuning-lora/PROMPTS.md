# Sesión 8 · Fine-tuning con LoRA y QLoRA · Prompts para Claude Code

Estos son los prompts que usamos en la práctica, en el mismo orden que en clase. Cópialos y pégalos en Claude Code uno a uno.

**Cómo usarlos**
1. Pega el prompt del paso y deja que Claude Code proponga los cambios.
2. **Lee el código antes de aceptar** (y los comandos, como `pip install`, antes de permitirlos).
3. Ejecuta y compara con el apartado *Qué deberías ver*.
4. Si no sale lo esperado, vuelve a pedírselo con lo que has aprendido.

> Antes de empezar: una cuenta gratuita de Google para usar Colab (o de Kaggle). El entrenamiento se hace en su GPU gratuita (Entorno de ejecución → T4 GPU): tu portátil no entrena nada. El notebook `08_finetuning.ipynb` crea el dataset solo. Nunca hace falta pagar Colab Pro.

El resultado de referencia, con todo el código comentado, está en la carpeta `finetuning-lora` del material de la sesión.

---

## Paso 1 · Preparar el dataset

**Qué construye**

- 30 dudas internas de Nexa: RRHH, IT y gastos
- Todas con titular, 3 vinetas y firma
- Una linea de JSONL por ejemplo
- 6 preguntas de prueba, aparte

**Prompt**

```text
Crea un dataset pequeno de fine-tuning: 30 pares pregunta-respuesta sobre dudas internas de una empresa (RRHH, IT y gastos), todos con el mismo formato: un titular en una linea, tres vinetas que empiecen por '- ' y la firma '— Equipo de Personas de Nexa'. Sin cifras concretas: queremos ensenar el formato, no datos. Guardalo en JSONL con los campos instruccion y respuesta, aparta 6 preguntas de prueba que no se usen para entrenar, ensename dos ejemplos y anade una funcion cumple_formato() que compruebe el formato con codigo.
```

**Qué deberías ver**

Los 30 ejemplos cumplen el formato: True. Si el dataset no es consistente, el modelo aprende la inconsistencia.

---

## Paso 2 · Cargar el modelo con QLoRA (4 bits)

**Qué construye**

- Qwen2.5-1.5B-Instruct, un modelo pequeno
- BitsAndBytesConfig: 4 bits, tipo nf4
- device_map='auto': a la GPU
- Medir la memoria que ocupa

**Prompt**

```text
Prepara un notebook para Google Colab o Kaggle (GPU gratuita). Instala peft, bitsandbytes, datasets y accelerate. Carga Qwen/Qwen2.5-1.5B-Instruct cuantizado a 4 bits con BitsAndBytesConfig (nf4, compute en float16, double quant) y device_map='auto'. Confirma que esta en la GPU y muestra cuanta memoria ocupa el modelo y cuanta hay en la GPU.
```

**Qué deberías ver**

GPU Tesla T4 de 15,6 GB. El modelo en 4 bits ocupa 1,12 GB: sobra muchisimo sitio.

### Variación en vivo: Variación · ¿cuanto ahorran los 4 bits?

```text
Anade una celda que cargue el mismo modelo en float16, mida su memoria con get_memory_footprint(), la compare con la del modelo en 4 bits y lo borre de la GPU.
```

**Qué demuestra**

16 bits: 3,09 GB. 4 bits: 1,12 GB. 2,8 veces menos. No llega a 4 veces porque hay partes que no se cuantizan (los embeddings y algunas capas se quedan en 16 bits).

---

## Paso 3 · Entrenar el adapter LoRA

**Qué construye**

- LoraConfig: r=16, alpha=32, q_proj y v_proj
- get_peft_model: cuanto se entrena
- Trainer: 5 epocas sobre los 30 ejemplos
- El loss, paso a paso

**Prompt**

```text
Configura LoRA con peft: un LoraConfig con r=16, lora_alpha=32, dropout 0.05 y target_modules q_proj y v_proj. Antes guarda las respuestas del modelo base a las preguntas de prueba. Prepara el modelo con prepare_model_for_kbit_training, envuelvelo con get_peft_model y muestra los parametros entrenables. Tokeniza el dataset para que solo se aprenda de la respuesta (etiquetas -100 en la pregunta) y entrena 5 epocas con Trainer, mostrando como baja el loss.
```

**Qué deberías ver**

25 segundos de entrenamiento. El loss baja de 3,26 a 2,16... y se queda ahi. Guardad este numero.

### Variación en vivo: Variación · ¿cuanto pesa el adapter segun el rank?

```text
Anade una celda que calcule, para rank 4, 8, 16 y 64, los parametros entrenables, el porcentaje del modelo y lo que ocuparia el adapter en disco.
```

**Qué demuestra**

Crece en proporcion al rank: de 2,2 MB con r=4 a 34,9 MB con r=64. Incluso el mas grande es el 0,56 % del modelo. El modelo entero pesa 3,1 GB.

---

## Paso 4 · Probar y fusionar el adapter

**Qué construye**

- Las 6 preguntas de prueba al modelo base
- Las mismas al modelo ajustado
- Contar con codigo cuantas cumplen el formato
- Fusionar con merge_and_unload

**Prompt**

```text
Prueba el modelo antes y despues del fine-tuning: haz las 6 preguntas de prueba al modelo base (guardadas antes de entrenar) y al ajustado, cuenta con cumple_formato() cuantas respuestas cumplen el formato y ensename dos comparaciones completas. Despues guarda el adapter, recarga el modelo base en 16 bits, fusiona el adapter con merge_and_unload y guarda el modelo fusionado.
```

**Qué deberías ver**

0 de 6 antes y 0 de 6 despues. El entrenamiento real no ha aprendido el formato.

### Variación en vivo: Variación · la FORMA, no los DATOS

```text
Anade una celda que pregunte al modelo ajustado '¿Cuantos dias de vacaciones tengo al ano?' y compara la respuesta con el dato real del manual de Nexa (23 dias laborables).
```

**Qué demuestra**

Contesta muy seguro con '20 dias en Espana' y una lista de paises. En el manual de Nexa son 23 dias laborables. Se lo inventa: los datos se los da el RAG, no el fine-tuning.

---

## Paso 5 · Cierre: ¿fine-tuning o RAG?

**Qué construye**

- Lo que hemos visto con datos reales
- Cuando conviene cada uno
- El material que os llevais
- Los dos ejercicios

**Prompt**

```text
Anade comentarios didacticos a todo el notebook y una celda final que explique cuando conviene fine-tuning frente a RAG. Escribe un README que resuma LoRA, QLoRA, el dataset y el uso de GPU gratuita en Colab y Kaggle, y deja el notebook y el adapter listos para compartir como material de clase.
```

**Qué deberías ver**

La prueba de hoy: el ajustado se inventa los dias de vacaciones. Ese dato lo pone el RAG de la S5.

---

## Ejercicio 1 · Ensena un estilo a un modelo con LoRA

**Qué construye**

- 15 ejemplos con el estilo
- Entrenar el adapter
- Base frente a ajustado
- Medir la diferencia

**Prompt**

```text
En Colab o Kaggle (GPU gratuita), ajusta con LoRA un modelo pequeno (Qwen2.5-1.5B-Instruct en 4 bits) sobre 15 ejemplos pregunta-respuesta de atencion al cliente de una tienda online, todos en tono formal: de usted, empezando por 'Estimado cliente' y con la firma 'Atentamente, Servicio de Atencion al Cliente'. Usa LoRA en todas las capas lineales, r=8 y unas 12 epocas. Compara el modelo base y el ajustado con las mismas 4 preguntas nuevas y cuenta con codigo cuantas respuestas son formales.
```

**Qué deberías ver**

Cuantas respuestas formales da el base y cuantas el ajustado, con las mismas preguntas.

---

## Ejercicio 2 · Fine-tuning multimodal (reto, pesado)

**Qué construye**

- Tickets sinteticos
- Modelo de vision pequeno con LoRA
- Entrenar
- Antes frente a despues

**Prompt**

```text
En Kaggle con GPU (recomendado; en Colab gratis puede no terminar), genera con PIL 60 tickets sinteticos con su respuesta correcta en JSON (comercio, fecha, total) y 10 de prueba. Ajusta con LoRA el modelo de vision HuggingFaceTB/SmolVLM-256M-Instruct (LoRA en q, k, v y o del modelo de lenguaje) para que, dada la imagen y la pregunta 'Extrae los datos del ticket.', devuelva siempre ese JSON. Mide cuantos tickets de prueba lee con el JSON exacto antes y despues, y guarda el adapter.
```

**Qué deberías ver**

Cuantos de los 10 tickets de prueba devuelve con el JSON exacto, antes y despues.

---

*Material del Master AI Engineer · The Power · Ignacio de Pastors*
