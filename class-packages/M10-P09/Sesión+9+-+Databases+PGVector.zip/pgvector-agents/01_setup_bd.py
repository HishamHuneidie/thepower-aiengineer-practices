"""Paso 1 · PostgreSQL + pgvector: activar la extension y crear una tabla con columna vector."""
from db import DIMENSIONES, conectar

conn = conectar(registrar_vector=False)   # la extension todavia no existe

# 1) Activar pgvector: a partir de aqui Postgres entiende el tipo "vector"
conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
version = conn.execute("SELECT extversion FROM pg_extension WHERE extname = 'vector'").fetchone()[0]
print(f"Extension vector activa (pgvector {version})")

# 2) Una tabla normal de Postgres... con una columna de 384 numeros
conn.execute("DROP TABLE IF EXISTS documentos")
conn.execute(f"""
    CREATE TABLE documentos (
        id        SERIAL PRIMARY KEY,
        texto     TEXT NOT NULL,
        embedding VECTOR({DIMENSIONES})
    )
""")

# 3) Ensenar la tabla creada
print("\nTabla 'documentos':")
for nombre, tipo in conn.execute("""
        SELECT a.attname, format_type(a.atttypid, a.atttypmod)
        FROM pg_attribute a
        WHERE a.attrelid = 'documentos'::regclass AND a.attnum > 0 AND NOT a.attisdropped
        ORDER BY a.attnum"""):
    print(f"  {nombre:<10} {tipo}")
servidor = conn.execute("SHOW server_version").fetchone()[0]
print(f"\nConectado a PostgreSQL {servidor}")
