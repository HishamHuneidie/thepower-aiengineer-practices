# Sesión 4 · Bases de datos para agentes: PostgreSQL y pgvector · Prompts para Claude Code

Estos son los prompts que usamos en la práctica, en el mismo orden que en clase. Cópialos y pégalos en Claude Code uno a uno.

**Cómo usarlos**
1. Pega el prompt del paso y deja que Claude Code proponga los cambios.
2. **Lee el código antes de aceptar** (y los comandos, como `pip install`, antes de permitirlos).
3. Ejecuta y compara con el apartado *Qué deberías ver*.
4. Si no sale lo esperado, vuelve a pedírselo con lo que has aprendido.

> Antes de empezar: un PostgreSQL con pgvector. Lo más fácil: una cuenta gratuita en [Neon](https://console.neon.tech) (o Supabase), copiando la *connection string* (con *Show password*) en el `.env` como `DATABASE_URL`; tienes la plantilla en `.env.example`. También vale Docker (`pgvector/pgvector`). **Nunca compartas tu `.env`.**

El resultado de referencia, con todo el código comentado, está en la carpeta `pgvector-agents` del material de la sesión.

---

## Paso 1 · Postgres + pgvector

**Qué construye**

- Conectar con la cadena del .env
- Activar pgvector: CREATE EXTENSION vector
- Tabla documentos con columna vector(384)
- Ensenar la tabla creada

**Prompt**

```text
Crea un proyecto Python nuevo llamado pgvector-agents. Tengo una base de datos PostgreSQL en Neon (plan gratuito) y su cadena de conexion en el .env como DATABASE_URL (vale igual un Postgres con pgvector en Docker). Conecta con psycopg, crea la extension vector con CREATE EXTENSION vector y crea una tabla documentos con columnas id, texto y embedding de tipo vector(384). Ensename la tabla creada.
```

**Qué deberías ver**

Pgvector 0.8.6 activo y una tabla normal cuya ultima columna es vector(384). PostgreSQL 18 en Neon.

---

## Paso 2 · Generar y guardar embeddings

**Qué construye**

- Modelo local multilingue
- 10 politicas reales de la tienda
- Insertar texto + vector
- Ver lo guardado

**Prompt**

```text
Instala sentence-transformers. Coge un pequeno corpus de 10 frases de ejemplo (las politicas de una tienda online), genera su embedding con un modelo local multilingue (paraphrase-multilingual-MiniLM-L12-v2, 384 dimensiones) e insertalos en la tabla documentos junto a su texto. Muestra por consola que se han guardado con su vector.
```

**Qué deberías ver**

Cada politica con el principio de su vector: numeros pequenos, positivos y negativos. Sin ellos no hay busqueda.

### Variación en vivo: ¿que es estar cerca?

```text
Calcula y muestra la matriz de similitud coseno entre 4 frases: dos sobre un paquete danado, una sobre cuando llega un pedido y otra sin relacion (por ejemplo, la paella).
```

**Qué demuestra**

Dos frases sobre un paquete danado: 0,64, aunque no comparten palabras. La paella: casi 0 con todo. Eso es 'estar cerca'.

---

## Paso 3 · Busqueda por similitud

**Qué construye**

- La pregunta se convierte en vector
- ORDER BY embedding <=> pregunta
- LIMIT 3: los mas parecidos
- Distancia y similitud de cada uno

**Prompt**

```text
Implementa una busqueda por similitud: dada una pregunta del usuario, genera su embedding y consulta la tabla ordenando por el operador <=> (distancia coseno) para traer los 3 textos mas parecidos. Prueba con la pregunta '¿Cuanto tarda en llegar mi paquete?' y muestra los resultados ordenados por relevancia.
```

**Qué deberías ver**

La buena ('se envian en 24-48 horas') sale SEGUNDA. El top-3 existe para esto: la primera no siempre es la mejor.

### Variación en vivo: el modelo importa

```text
Compara dos modelos de embeddings (all-MiniLM-L6-v2 y paraphrase-multilingual-MiniLM-L12-v2) con el mismo corpus y dos preguntas en espanol, mostrando el documento mas parecido segun cada modelo.
```

**Qué demuestra**

Con el modelo en ingles, '¿puedo pagar con el movil?' devuelve la garantia. Con el multilingue, Bizum. Mismo codigo, otro modelo, otro resultado.

### Variación en vivo: palabras frente a significado

```text
Busca '¿Puedo pagar con el movil?' de dos formas: con texto ILIKE '%movil%' y por significado con <=>, y compara los resultados.
```

**Qué demuestra**

Por palabras: 0 resultados, porque ninguna politica dice 'movil'. Por significado: 'Aceptamos Bizum'. Es la razon de ser de pgvector.

---

## Paso 4 · Indice HNSW + multi-tenancy

**Qué construye**

- Indice HNSW sobre embedding
- Columna tenant_id
- Segundo cliente: una clinica dental
- La misma pregunta, filtrada por cliente

**Prompt**

```text
Crea un indice HNSW sobre la columna embedding para acelerar la busqueda. Luego anade una columna tenant_id a la tabla, mete datos de dos clientes distintos (la tienda y una clinica dental) y modifica la busqueda para que filtre por tenant_id, demostrando que un cliente solo ve sus propios documentos.
```

**Qué deberías ver**

La misma pregunta, '¿que horario teneis?', devuelve el horario de la tienda o el de la clinica segun quien pregunte.

### Variación en vivo: ¿usa Postgres el indice?

```text
Muestra con EXPLAIN el plan de la busqueda por similitud, primero tal cual y despues con enable_seqscan = off, para ver cuando usa Postgres el indice HNSW.
```

**Qué demuestra**

Con 14 filas recorre la tabla entera (Seq Scan): es mas barato. Cuando el volumen lo justifica, usa el HNSW (Index Scan). El indice es para escalar.

### Variación en vivo: Row-Level Security

```text
Activa Row-Level Security en documentos con una politica por app.tenant_id, crea un rol de aplicacion sin privilegios y demuestra que la misma consulta sin WHERE devuelve solo los documentos del tenant de la sesion.
```

**Qué demuestra**

El propietario ve las 14 filas: se salta RLS. El rol de la app ve 10 o 4 segun el cliente, y 0 sin cliente, con la misma consulta sin WHERE.

---

## Bonus · PostGIS + pgvector

**Qué construye**

- Activar PostGIS
- 6 tiendas fisicas en Madrid
- Cliente en Atocha: '¿donde recojo mi pedido?'
- Solo distancia frente a distancia + significado

**Prompt**

```text
Activa PostGIS en la base de datos. Crea una tabla tiendas_fisicas con nombre, servicios, embedding vector(384) y ubicacion geography(Point) con 6 tiendas de Madrid. Dado un cliente en la estacion de Atocha y la pregunta '¿Donde puedo recoger mi pedido?', muestra primero las 3 tiendas mas cercanas y despues las que estan a menos de 4 km ordenadas por similitud con la pregunta, con su distancia en km.
```

**Qué deberías ver**

La mas cercana, Atocha, no recoge pedidos. Con distancia + significado salen Salamanca y Sol, que si.

---

## Paso 6 · Cierre y material

**Qué construye**

- Comentarios didacticos en el codigo
- esquema.sql comentado
- README con los conceptos
- Proyecto listo para compartir

**Prompt**

```text
Anade comentarios didacticos a todo el codigo y al esquema SQL, y escribe un README que explique embeddings, similitud, el indice HNSW, el aislamiento multi-tenant y el bonus de PostGIS. Deja el proyecto limpio para compartirlo como material de clase.
```

**Qué deberías ver**

Un archivo por paso, el esquema SQL, el README, las variaciones en extras y las soluciones.

---

*Material del Master AI Engineer · The Power · Ignacio de Pastors*
