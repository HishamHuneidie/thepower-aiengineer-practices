# pgvector-agents · Master AI Engineer · Sesion 4

Bases de datos para agentes: **PostgreSQL + pgvector** para buscar por significado, con aislamiento por cliente,
y de bonus **PostGIS** para buscar tambien por distancia. Embeddings en local y gratis con sentence-transformers.

## Puesta en marcha
1. Una base de datos PostgreSQL con pgvector. Cualquiera de estas vale, **el codigo es el mismo**:
   - **Neon** o **Supabase** (nube, plan gratuito, pgvector y PostGIS incluidos) · la que usamos en clase
   - **Docker**: `docker run -e POSTGRES_PASSWORD=postgres -p 5432:5432 pgvector/pgvector:pg17`
   - PostgreSQL instalado en tu equipo **con la extension pgvector** (en Windows no viene incluida)
2. Copia `.env.example` como `.env` y pega tu `DATABASE_URL`. **Nunca subas el `.env` a git.**
3. `python -m venv .venv`, activalo e instala: `pip install -r requirements.txt`
   (la primera ejecucion descarga el modelo de embeddings, unos 470 MB)

## Los conceptos
- **Embedding**: un vector (aqui de 384 numeros) que representa el significado de un texto. Textos parecidos = vectores cercanos.
- **Distancia coseno** (`<=>`): 0 = mismo significado. `1 - distancia` = similitud.
- **pgvector**: la extension que da a Postgres el tipo `vector`, el operador `<=>` y los indices vectoriales.
- **HNSW**: indice aproximado, muy rapido a escala. Con pocas filas Postgres prefiere recorrer la tabla (lo vemos con `EXPLAIN`).
- **Multi-tenancy**: `tenant_id` + filtro en cada consulta, o mejor, **Row-Level Security** en la propia base de datos.
- **PostGIS** (bonus): tipo `geography`, `ST_Distance`, `ST_DWithin` e indice GiST para buscar por cercania.

## Los pasos
| Archivo | Que demuestra |
|---|---|
| `01_setup_bd.py` | `CREATE EXTENSION vector` y la tabla `documentos` con columna `vector(384)` |
| `02_embeddings.py` | 10 politicas de la tienda convertidas en vectores y guardadas junto a su texto |
| `03_busqueda.py` | Los 3 textos mas parecidos a una pregunta con `ORDER BY embedding <=> pregunta` |
| `04_hnsw_tenants.py` | Indice HNSW + `tenant_id`: la tienda y la clinica solo ven sus documentos |
| `05_bonus_gis.py` | PostGIS + pgvector: la tienda fisica mas cercana que ofrece lo que buscas |
| `esquema.sql` | El esquema completo, comentado |
| `db.py` · `corpus.py` | Conexion, modelo de embeddings y textos compartidos |

## Extras (variaciones vistas en clase)
- `extras/paso2_que_es_estar_cerca.py` · matriz de similitud entre frases
- `extras/paso3_el_modelo_importa.py` · all-MiniLM-L6-v2 (ingles) frente al modelo multilingue
- `extras/paso3_palabras_vs_significado.py` · `ILIKE` frente a `<=>`
- `extras/paso4_usa_el_indice.py` · `EXPLAIN`: cuando usa Postgres el indice HNSW
- `extras/paso4_row_level_security.py` · aislamiento con RLS y un rol de aplicacion sin privilegios

## Ejercicios para casa
- **Ejercicio 1 · Busqueda por significado con PGVector** (basico). Solucion: `soluciones/ejercicio1_busqueda_significado.py`
- **Ejercicio 2 · Reto: RAG multi-tenant con inteligencia geoespacial**. Solucion: `soluciones/ejercicio2_multitenant_gis.py`

## Notas
- `all-MiniLM-L6-v2` esta entrenado en ingles y falla con preguntas en espanol; usamos `paraphrase-multilingual-MiniLM-L12-v2`, con las mismas 384 dimensiones.
- La base de datos siempre devuelve "los mas parecidos", aunque no se parezcan nada: en un sistema real, pon un umbral de similitud.
- El propietario de la tabla (en Neon, `neondb_owner`) se salta RLS: la app debe usar un rol sin privilegios.
