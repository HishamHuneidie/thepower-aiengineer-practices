"""Variacion paso 3 · El modelo importa: el mismo corpus y las mismas preguntas con dos modelos de embeddings."""
import sys
from pathlib import Path

import numpy as np
from sentence_transformers import SentenceTransformer

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from corpus import CORPUS  # noqa: E402
PREGUNTAS = ["¿Cuánto tarda en llegar mi paquete?", "¿Puedo pagar con el móvil?"]

for nombre in ["all-MiniLM-L6-v2", "paraphrase-multilingual-MiniLM-L12-v2"]:
    modelo = SentenceTransformer(nombre)
    docs = modelo.encode(CORPUS, normalize_embeddings=True)
    print(f"── {nombre} ──")
    for p in PREGUNTAS:
        sim = docs @ modelo.encode(p, normalize_embeddings=True)
        mejor = int(np.argmax(sim))
        print(f"  {p:<37} -> {sim[mejor]:.2f} | {CORPUS[mejor]}")
    print()
