"""Variacion paso 4 · Row-Level Security: que sea la BASE DE DATOS quien aisle a cada cliente.

En el paso 4 el aislamiento depende de que el codigo no olvide el WHERE tenant_id = ...
Con RLS, Postgres filtra solo, aunque la consulta no lleve ningun filtro.
Ojo: el usuario propietario (en Neon, neondb_owner) puede saltarse RLS. La aplicacion debe
conectarse con un rol SIN privilegios: aqui lo creamos y lo usamos con SET ROLE.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import conectar  # noqa: E402

conn = conectar()
CONSULTA = "SELECT count(*), min(texto) FROM documentos"

# 1) Activar RLS y la politica: solo se ven las filas del tenant de la sesion
conn.execute("ALTER TABLE documentos ENABLE ROW LEVEL SECURITY")
conn.execute("DROP POLICY IF EXISTS aislamiento_tenant ON documentos")
conn.execute("""CREATE POLICY aislamiento_tenant ON documentos
                USING (tenant_id = current_setting('app.tenant_id', true))""")

# 2) Un rol de aplicacion sin privilegios, con permiso solo de lectura
if not conn.execute("SELECT 1 FROM pg_roles WHERE rolname = 'app_agente'").fetchone():
    conn.execute("CREATE ROLE app_agente NOLOGIN")
conn.execute("GRANT app_agente TO CURRENT_USER WITH SET TRUE")
conn.execute("GRANT SELECT ON documentos TO app_agente")
print("RLS activado: politica aislamiento_tenant + rol de aplicacion app_agente\n")

usuario = conn.execute("SELECT current_user").fetchone()[0]
n = conn.execute(CONSULTA).fetchone()[0]
print(f"Como propietario ({usuario}): {n} filas  <- el propietario se salta RLS\n")

# 3) La MISMA consulta, sin WHERE, como app_agente y con dos clientes distintos
conn.execute("SET ROLE app_agente")
for tenant in ("tienda", "clinica"):
    conn.execute("SELECT set_config('app.tenant_id', %s, false)", (tenant,))
    n, ejemplo = conn.execute(CONSULTA).fetchone()
    print(f"app_agente · tenant '{tenant}': {n:>2} filas  (p.ej. '{ejemplo}')")
conn.execute("SELECT set_config('app.tenant_id', '', false)")
print(f"app_agente · sin tenant:     {conn.execute(CONSULTA).fetchone()[0]:>2} filas")
conn.execute("RESET ROLE")

# 4) Dejarlo como estaba para el resto de la demo
conn.execute("DROP POLICY aislamiento_tenant ON documentos")
conn.execute("ALTER TABLE documentos DISABLE ROW LEVEL SECURITY")
print("\n(RLS desactivado de nuevo para seguir con la demo)")
