"""Variacion paso 4 · ¿Usa Postgres el indice HNSW? EXPLAIN antes y despues."""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import conectar, embedding  # noqa: E402

conn = conectar()
conn.execute("ANALYZE documentos")   # estadisticas al dia: el planificador sabe cuantas filas hay
q = embedding("¿Qué horario tenéis?")
CONSULTA = "EXPLAIN SELECT texto FROM documentos ORDER BY embedding <=> %s LIMIT 3"



def mostrar(plan):
    for (linea,) in plan:   # el vector de 384 numeros se recorta para que se lea el plan
        print("   " + re.sub(r"'\[[^\]]*\]'", "'[0.056, -0.040, ... 384 numeros]'", linea))


print("1) Con 14 filas, Postgres decide que recorrer la tabla entera es mas barato:\n")
mostrar(conn.execute(CONSULTA, (q,)))

# Forzamos a que no recorra la tabla entera, para ver el indice en accion
conn.execute("SET enable_seqscan = off")
print("\n2) Con miles de filas (aqui lo simulamos con enable_seqscan = off) usa el indice HNSW:\n")
mostrar(conn.execute(CONSULTA, (q,)))
conn.execute("RESET enable_seqscan")
