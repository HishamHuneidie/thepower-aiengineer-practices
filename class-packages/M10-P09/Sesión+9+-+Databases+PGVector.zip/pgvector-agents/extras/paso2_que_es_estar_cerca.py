"""Variacion paso 2 · ¿Que significa que dos embeddings esten 'cerca'? Similitud coseno entre frases."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import embedding  # noqa: E402

FRASES = [
    "Mi paquete llegó roto.",
    "El producto se ha dañado en el envío.",
    "¿Cuándo llega mi pedido?",
    "Me encanta la paella valenciana.",
]
v = embedding(FRASES)          # vectores normalizados: el producto escalar ES la similitud coseno
sim = v @ v.T

print("Similitud coseno (1 = mismo significado, 0 = nada que ver)\n")
print(" " * 42 + "".join(f"  F{j + 1}  " for j in range(len(FRASES))))
for i, f in enumerate(FRASES):
    print(f"F{i + 1} {f:<38}" + "".join(f" {sim[i, j]:5.2f} " for j in range(len(FRASES))))
