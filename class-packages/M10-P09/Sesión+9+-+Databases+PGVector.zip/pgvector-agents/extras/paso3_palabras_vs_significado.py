"""Variacion paso 3 · Buscar por palabras (ILIKE) frente a buscar por significado (<=>)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import conectar, embedding  # noqa: E402

conn = conectar()
pregunta, palabra = "¿Puedo pagar con el móvil?", "móvil"
print(f"Pregunta: {pregunta}\n")

# 1) La busqueda de toda la vida: que el texto contenga la palabra
filas = conn.execute("SELECT texto FROM documentos WHERE texto ILIKE %s", (f"%{palabra}%",)).fetchall()
print(f"1) Por PALABRAS (texto ILIKE '%{palabra}%'): {len(filas)} resultados")
for (t,) in filas:
    print(f"   {t}")

# 2) La busqueda por significado: el vector mas cercano
q = embedding(pregunta)
texto, d = conn.execute("SELECT texto, embedding <=> %s FROM documentos ORDER BY embedding <=> %s LIMIT 1",
                        (q, q)).fetchone()
print(f"\n2) Por SIGNIFICADO (embedding <=> pregunta): similitud {1 - d:.2f}")
print(f"   {texto}")
