"""Paso 4 · Indice HNSW + multi-tenancy: cada cliente solo ve sus propios documentos."""
from corpus import CLINICA
from db import conectar, embedding

conn = conectar()

# 1) Indice HNSW: busqueda aproximada muy rapida sobre la distancia coseno
conn.execute("CREATE INDEX IF NOT EXISTS documentos_embedding_hnsw ON documentos USING hnsw (embedding vector_cosine_ops)")
print("Indice HNSW creado sobre documentos.embedding")

# 2) Multi-tenancy: una columna tenant_id. Los documentos actuales son de la tienda...
conn.execute("ALTER TABLE documentos ADD COLUMN IF NOT EXISTS tenant_id TEXT NOT NULL DEFAULT 'tienda'")

# ...y damos de alta un segundo cliente: una clinica dental
conn.execute("DELETE FROM documentos WHERE tenant_id = 'clinica'")
with conn.cursor() as cur:
    cur.executemany("INSERT INTO documentos (texto, embedding, tenant_id) VALUES (%s, %s, 'clinica')",
                    list(zip(CLINICA, embedding(CLINICA))))
for tenant, n in conn.execute("SELECT tenant_id, count(*) FROM documentos GROUP BY tenant_id ORDER BY tenant_id"):
    print(f"  tenant '{tenant}': {n} documentos")


# 3) La misma busqueda, SIEMPRE filtrada por el cliente que pregunta
def buscar(pregunta: str, tenant: str, k: int = 2):
    q = embedding(pregunta)
    return conn.execute("""
        SELECT texto, embedding <=> %s AS distancia
        FROM documentos
        WHERE tenant_id = %s                 -- el filtro que aisla a cada cliente
        ORDER BY embedding <=> %s
        LIMIT %s
    """, (q, tenant, q, k)).fetchall()


pregunta = "¿Qué horario tenéis?"
for tenant in ("tienda", "clinica"):
    print(f"\n[{tenant}] {pregunta}")
    for texto, d in buscar(pregunta, tenant):
        print(f"   {1 - d:.3f} | {texto}")
