-- ============================================================================
-- Esquema de la Sesion 4 · PostgreSQL + pgvector (+ PostGIS de bonus)
-- Funciona igual en Neon, Supabase, Docker (pgvector/pgvector) o un Postgres local con pgvector.
-- ============================================================================

-- 1) Extensiones: Postgres aprende a guardar vectores (y, de bonus, puntos en el mapa)
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS postgis;

-- 2) Documentos: una tabla NORMAL con una columna de 384 numeros
--    (384 = dimensiones del modelo paraphrase-multilingual-MiniLM-L12-v2)
CREATE TABLE documentos (
    id         SERIAL PRIMARY KEY,
    texto      TEXT NOT NULL,                       -- el dato de siempre
    embedding  VECTOR(384),                         -- su significado, en numeros
    tenant_id  TEXT NOT NULL DEFAULT 'tienda'       -- a que cliente pertenece (multi-tenancy)
);

-- 3) Busqueda por significado: los 3 textos mas cercanos a un vector de consulta
--    <=> = distancia coseno (0 = mismo significado). Siempre filtrando por cliente.
-- SELECT texto, 1 - (embedding <=> :consulta) AS similitud
-- FROM documentos
-- WHERE tenant_id = :cliente
-- ORDER BY embedding <=> :consulta
-- LIMIT 3;

-- 4) Indice HNSW: busqueda aproximada muy rapida (a partir de miles de filas se nota)
CREATE INDEX documentos_embedding_hnsw ON documentos USING hnsw (embedding vector_cosine_ops);

-- 5) Aislamiento en la propia base de datos (Row-Level Security)
--    La app se conecta con un rol SIN privilegios; el propietario se salta RLS.
ALTER TABLE documentos ENABLE ROW LEVEL SECURITY;
CREATE POLICY aislamiento_tenant ON documentos
    USING (tenant_id = current_setting('app.tenant_id', true));
-- En cada conexion de la app:  SELECT set_config('app.tenant_id', 'tienda', false);

-- 6) Bonus GIS: tiendas fisicas con su vector (que ofrecen) y su punto en el mapa (donde estan)
CREATE TABLE tiendas_fisicas (
    id         SERIAL PRIMARY KEY,
    nombre     TEXT,
    servicios  TEXT,
    embedding  VECTOR(384),
    ubicacion  GEOGRAPHY(POINT, 4326)               -- longitud/latitud reales (WGS84)
);
CREATE INDEX ON tiendas_fisicas USING gist (ubicacion);   -- indice espacial

-- Significado + distancia en una consulta: a menos de 4 km y ordenadas por lo que ofrecen
-- SELECT nombre, servicios,
--        ST_Distance(ubicacion, ST_MakePoint(:lon, :lat)::geography) / 1000 AS km
-- FROM tiendas_fisicas
-- WHERE ST_DWithin(ubicacion, ST_MakePoint(:lon, :lat)::geography, 4000)
-- ORDER BY embedding <=> :consulta;
