"""Conexion a PostgreSQL + modelo de embeddings, compartidos por todos los pasos."""
import os

import psycopg
from dotenv import load_dotenv
from pgvector.psycopg import register_vector

load_dotenv()

# Modelo local y gratuito: textos -> vectores de 384 dimensiones.
# Multilingue: all-MiniLM-L6-v2 (solo ingles) falla con frases en espanol (ver extras/paso3_el_modelo_importa.py)
MODELO = "paraphrase-multilingual-MiniLM-L12-v2"
DIMENSIONES = 384


def conectar(registrar_vector: bool = True) -> psycopg.Connection:
    """Abre la conexion con la cadena del .env (Neon, Supabase, Docker o local: el codigo es el mismo)."""
    conn = psycopg.connect(os.environ["DATABASE_URL"], autocommit=True)
    if registrar_vector:
        register_vector(conn)   # para pasar listas/arrays de Python como columnas vector
    return conn


_modelo = None


def embedding(textos):
    """Convierte uno o varios textos en embeddings (el modelo se descarga la primera vez, ~470 MB)."""
    global _modelo
    if _modelo is None:
        from sentence_transformers import SentenceTransformer
        _modelo = SentenceTransformer(MODELO)
    return _modelo.encode(textos, normalize_embeddings=True)
