"""Paso 2 · Generar embeddings con un modelo local y guardarlos junto a su texto."""
from corpus import CORPUS
from db import MODELO, conectar, embedding


conn = conectar()
vectores = embedding(CORPUS)   # 10 textos -> 10 vectores de 384 numeros
print(f"Modelo {MODELO}: {len(vectores)} embeddings de {len(vectores[0])} dimensiones\n")

conn.execute("TRUNCATE documentos RESTART IDENTITY")
with conn.cursor() as cur:
    cur.executemany("INSERT INTO documentos (texto, embedding) VALUES (%s, %s)", list(zip(CORPUS, vectores)))

# Comprobar lo guardado: el texto y el principio de su vector
for id_, texto, emb in conn.execute("SELECT id, texto, embedding FROM documentos ORDER BY id"):
    inicio = ", ".join(f"{x:+.3f}" for x in emb.to_numpy()[:4])
    print(f"{id_:>2} | [{inicio}, ...] | {texto}")
print(f"\nFilas guardadas: {conn.execute('SELECT count(*) FROM documentos').fetchone()[0]}")
