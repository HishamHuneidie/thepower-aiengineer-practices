"""Los textos de la demo: las politicas REALES de la tienda de las sesiones anteriores y la clinica del paso 4."""

CORPUS = [
    "Los pedidos se envían en 24-48 horas laborables.",
    "Puedes devolver cualquier producto durante los 30 días siguientes a la compra.",
    "El envío es gratuito en compras superiores a 50 euros.",
    "Aceptamos pago con tarjeta, PayPal y Bizum.",
    "Nuestro horario de atención al cliente es de lunes a viernes de 9 a 18 horas.",
    "Todos los productos tienen dos años de garantía.",
    "Puedes seguir tu pedido desde el enlace que recibes por email.",
    "Solo hacemos envíos a España peninsular y Baleares.",
    "Si el producto llega dañado, te enviamos uno nuevo sin coste.",
    "Puedes cambiar la talla de una prenda gratis en cualquier tienda física.",
]

CLINICA = [
    "Las citas se pueden cancelar hasta 24 horas antes sin coste.",
    "La primera revisión y la limpieza son gratuitas.",
    "Trabajamos con las principales mutuas de salud.",
    "El horario de la clínica es de lunes a sábado de 10 a 20 horas.",
]
