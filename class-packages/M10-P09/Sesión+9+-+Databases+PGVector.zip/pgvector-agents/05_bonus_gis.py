"""Bonus · Inteligencia geoespacial: PostGIS + pgvector en la MISMA consulta.

"¿Donde puedo recoger mi pedido cerca de mi?" = buscar por SIGNIFICADO (pgvector) y por DISTANCIA real (PostGIS).
"""
from db import DIMENSIONES, conectar, embedding

conn = conectar()
conn.execute("CREATE EXTENSION IF NOT EXISTS postgis")   # Postgres aprende geometria y geografia

# 1) Tiendas fisicas: datos normales + un vector (que ofrecen) + un punto en el mapa (donde estan)
conn.execute("DROP TABLE IF EXISTS tiendas_fisicas")
conn.execute(f"""
    CREATE TABLE tiendas_fisicas (
        id        SERIAL PRIMARY KEY,
        nombre    TEXT,
        servicios TEXT,
        embedding VECTOR({DIMENSIONES}),
        ubicacion GEOGRAPHY(POINT, 4326)      -- longitud/latitud reales (WGS84, como un GPS)
    )
""")
TIENDAS = [  # (nombre, servicios, latitud, longitud)
    ("Sol", "Recogida de pedidos online y cambios de talla.", 40.4169, -3.7035),
    ("Chamberí", "Taller de arreglos de ropa y cambios de talla.", 40.4340, -3.7040),
    ("Salamanca", "Personal shopper con cita previa y recogida de pedidos.", 40.4260, -3.6800),
    ("Chamartín", "Taquillas para recoger pedidos las 24 horas y punto de devolución.", 40.4722, -3.6829),
    ("Atocha", "Punto de devoluciones y taller de reparación de bicicletas.", 40.4066, -3.6910),
    ("Getafe", "Outlet con cambios de talla y devoluciones.", 40.3083, -3.7327),
]
vectores = embedding([t[1] for t in TIENDAS])
with conn.cursor() as cur:
    cur.executemany("""INSERT INTO tiendas_fisicas (nombre, servicios, embedding, ubicacion)
                       VALUES (%s, %s, %s, ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography)""",
                    [(n, s, v, lon, lat) for (n, s, lat, lon), v in zip(TIENDAS, vectores)])
conn.execute("CREATE INDEX ON tiendas_fisicas USING gist (ubicacion)")   # indice espacial
print(f"{len(TIENDAS)} tiendas fisicas en Madrid, cada una con su vector y su punto en el mapa\n")

# 2) El cliente esta en la estacion de Atocha y pregunta
lat, lon = 40.4065, -3.6897
pregunta = "¿Dónde puedo recoger mi pedido?"
q = embedding(pregunta)
print(f"Cliente en Atocha ({lat}, {lon}): {pregunta}\n")

# 3a) Solo distancia (PostGIS): las mas cercanas, ofrezcan lo que ofrezcan
print("A) Solo por DISTANCIA:")
for nombre, servicios, km in conn.execute("""
        SELECT nombre, servicios, ST_Distance(ubicacion, ST_MakePoint(%s, %s)::geography) / 1000
        FROM tiendas_fisicas ORDER BY ubicacion <-> ST_MakePoint(%s, %s)::geography LIMIT 3""",
        (lon, lat, lon, lat)):
    print(f"   {km:4.1f} km | {nombre:<10} | {servicios}")

# 3b) Significado + distancia: a menos de 4 km Y ordenadas por lo que ofrecen
print("\nB) A menos de 4 km y ordenadas por SIGNIFICADO:")
for nombre, servicios, sim, km in conn.execute("""
        SELECT nombre, servicios,
               1 - (embedding <=> %s)                                     AS similitud,
               ST_Distance(ubicacion, ST_MakePoint(%s, %s)::geography) / 1000 AS km
        FROM tiendas_fisicas
        WHERE ST_DWithin(ubicacion, ST_MakePoint(%s, %s)::geography, 4000)   -- radio de 4 km
        ORDER BY embedding <=> %s
        LIMIT 3""", (q, lon, lat, lon, lat, q)):
    print(f"   {km:4.1f} km | similitud {sim:.2f} | {nombre:<10} | {servicios}")
