"""Paso 3 · Busqueda por similitud: los 3 textos mas parecidos a una pregunta, con el operador <=>."""
import sys

from db import conectar, embedding

pregunta = sys.argv[1] if len(sys.argv) > 1 else "¿Cuánto tarda en llegar mi paquete?"
conn = conectar()

q = embedding(pregunta)   # la pregunta se convierte en vector con el MISMO modelo

# <=> es la distancia coseno: 0 = mismo significado, 2 = opuesto. Ordenar por ella = vecinos mas cercanos
resultados = conn.execute("""
    SELECT texto, embedding <=> %s AS distancia
    FROM documentos
    ORDER BY embedding <=> %s
    LIMIT 3
""", (q, q)).fetchall()

print(f"Pregunta: {pregunta}\n")
for i, (texto, distancia) in enumerate(resultados, 1):
    print(f"{i}. distancia {distancia:.3f} · similitud {1 - distancia:.3f} | {texto}")
