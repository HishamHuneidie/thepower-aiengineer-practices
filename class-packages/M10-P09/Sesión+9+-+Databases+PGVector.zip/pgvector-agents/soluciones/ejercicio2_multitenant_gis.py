"""Solucion del Ejercicio 2 (reto) · RAG multi-tenant con inteligencia geoespacial.

Dos clientes (tienda y clinica dental) con sus sedes en Madrid. Cada busqueda:
  1) solo ve las sedes de SU cliente (tenant_id),
  2) solo mira las que estan cerca del usuario (PostGIS, ST_DWithin),
  3) las ordena por lo bien que responden a la pregunta (pgvector, <=>).
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import DIMENSIONES, conectar, embedding  # noqa: E402

conn = conectar()
conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
conn.execute("CREATE EXTENSION IF NOT EXISTS postgis")
conn.execute("DROP TABLE IF EXISTS sedes")
conn.execute(f"""CREATE TABLE sedes (
    id SERIAL PRIMARY KEY, tenant_id TEXT NOT NULL, nombre TEXT, servicios TEXT,
    embedding VECTOR({DIMENSIONES}), ubicacion GEOGRAPHY(POINT, 4326))""")

SEDES = [  # (tenant, nombre, servicios, lat, lon)
    ("tienda", "Tienda Sol", "Recogida de pedidos online y cambios de talla.", 40.4169, -3.7035),
    ("tienda", "Tienda Chamberí", "Taller de arreglos de ropa y cambios de talla.", 40.4340, -3.7040),
    ("tienda", "Tienda Chamartín", "Taquillas para recoger pedidos las 24 horas.", 40.4722, -3.6829),
    ("clinica", "Clínica Ópera", "Urgencias dentales todos los días, también domingos y festivos.", 40.4180, -3.7090),
    ("clinica", "Clínica Retiro", "Ortodoncia invisible y blanqueamiento dental.", 40.4150, -3.6840),
    ("clinica", "Clínica Tetuán", "Implantes dentales y cirugía oral.", 40.4600, -3.6980),
]
with conn.cursor() as cur:
    cur.executemany("""INSERT INTO sedes (tenant_id, nombre, servicios, embedding, ubicacion)
                       VALUES (%s, %s, %s, %s, ST_SetSRID(ST_MakePoint(%s, %s), 4326)::geography)""",
                    [(t, n, s, v, lon, lat) for (t, n, s, lat, lon), v
                     in zip(SEDES, embedding([x[2] for x in SEDES]))])
conn.execute("CREATE INDEX ON sedes USING hnsw (embedding vector_cosine_ops)")
conn.execute("CREATE INDEX ON sedes USING gist (ubicacion)")
conn.execute("CREATE INDEX ON sedes (tenant_id)")


def buscar(tenant: str, pregunta: str, lat: float, lon: float, radio_km: float = 5, k: int = 2):
    q = embedding(pregunta)
    return conn.execute("""
        SELECT nombre, servicios, 1 - (embedding <=> %(q)s) AS similitud,
               ST_Distance(ubicacion, ST_MakePoint(%(lon)s, %(lat)s)::geography) / 1000 AS km
        FROM sedes
        WHERE tenant_id = %(tenant)s                                                   -- 1) aislamiento
          AND ST_DWithin(ubicacion, ST_MakePoint(%(lon)s, %(lat)s)::geography, %(radio)s)  -- 2) cerca
        ORDER BY embedding <=> %(q)s                                                   -- 3) significado
        LIMIT %(k)s""", {"q": q, "lat": lat, "lon": lon, "tenant": tenant, "radio": radio_km * 1000, "k": k}).fetchall()


SOL = (40.4169, -3.7035)   # el usuario esta en la Puerta del Sol
CASOS = [
    ("clinica", "Me duele muchísimo una muela y hoy es domingo"),
    ("tienda", "Necesito que me arreglen el bajo de un pantalón"),
    ("clinica", "¿Dónde puedo recoger mi pedido?"),   # la clinica NUNCA ve los datos de la tienda
]
for tenant, pregunta in CASOS:
    print(f"[{tenant}] usuario en Sol: {pregunta}")
    for nombre, servicios, sim, km in buscar(tenant, pregunta, *SOL):
        print(f"   {km:4.1f} km | similitud {sim:.2f} | {nombre:<16} | {servicios}")
    print()
