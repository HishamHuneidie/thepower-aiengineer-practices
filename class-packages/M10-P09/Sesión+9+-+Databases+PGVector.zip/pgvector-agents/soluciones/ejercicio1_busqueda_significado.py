"""Solucion del Ejercicio 1 · Busqueda por significado con PGVector.

5 frases con su embedding en una tabla propia y, dada una consulta, las 2 mas parecidas.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from db import DIMENSIONES, conectar, embedding  # noqa: E402

FRASES = [
    "El Real Madrid ganó la final de la Champions.",
    "Mañana lloverá en el norte de España.",
    "La nueva gráfica de NVIDIA duplica el rendimiento en IA.",
    "Las temperaturas bajarán este fin de semana.",
    "El Barça fichó a un delantero por 60 millones.",
]

conn = conectar()
conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
conn.execute("DROP TABLE IF EXISTS frases")
conn.execute(f"CREATE TABLE frases (id SERIAL PRIMARY KEY, texto TEXT, embedding VECTOR({DIMENSIONES}))")
with conn.cursor() as cur:
    cur.executemany("INSERT INTO frases (texto, embedding) VALUES (%s, %s)", list(zip(FRASES, embedding(FRASES))))

for consulta in ["¿Qué tiempo va a hacer?", "Noticias de fútbol"]:
    q = embedding(consulta)
    print(f"Consulta: {consulta}")
    for texto, d in conn.execute("SELECT texto, embedding <=> %s FROM frases ORDER BY embedding <=> %s LIMIT 2", (q, q)):
        print(f"   {1 - d:.2f} | {texto}")
    print()
conn.execute("DROP TABLE frases")
